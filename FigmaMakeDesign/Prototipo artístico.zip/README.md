
  # Prototipo artístico

  This is a code bundle for Prototipo artístico. The original project is available at https://www.figma.com/design/tikUiFVViwrFg3xDCPE8up/Prototipo-art%C3%ADstico.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  