import { createContext, useContext, useState, type ReactNode } from "react";

export type Screen =
  | "landing" | "login" | "role"
  | "dashboard-producer" | "dashboard-buyer" | "dashboard-transporter"
  | "marketplace" | "product" | "publish"
  | "quick-offer" | "negotiation"
  | "order" | "logistics" | "freight-compare"
  | "risk" | "trip"
  | "admin" | "design-system";

export type Role = "productor" | "comprador" | "transportista";

type NavState = {
  screen: Screen;
  role: Role;
  go: (s: Screen) => void;
  setRole: (r: Role) => void;
  productId: string;
  openProduct: (id: string) => void;
};

const Ctx = createContext<NavState | null>(null);

export function NavProvider({ children }: { children: ReactNode }) {
  const [screen, setScreen] = useState<Screen>("landing");
  const [role, setRole] = useState<Role>("comprador");
  const [productId, setProductId] = useState("p1");

  const go = (s: Screen) => {
    setScreen(s);
    if (typeof window !== "undefined") window.scrollTo({ top: 0 });
  };
  const openProduct = (id: string) => { setProductId(id); go("product"); };

  return (
    <Ctx.Provider value={{ screen, role, go, setRole, productId, openProduct }}>
      {children}
    </Ctx.Provider>
  );
}

export function useNav() {
  const v = useContext(Ctx);
  if (!v) throw new Error("useNav outside provider");
  return v;
}
