import type { Category } from "../components/brand/CategoryIcon";

export type RiskLevel = "bajo" | "medio" | "alto" | "critico";
export type NegType = "rapida" | "conversacional";

export type Product = {
  id: string;
  name: string;
  variety: string;
  category: Category;
  place: string;
  quantity: string;
  rangeLow: number;
  rangeHigh: number;
  unit: string;
  neg: NegType;
  risk: RiskLevel;
  confidence: number; // 0-100
  updated: string;
  producer: string;
  verified: boolean;
  image: string;
};

const U = (id: string, w = 800, h = 600) =>
  `https://images.unsplash.com/photo-${id}?w=${w}&h=${h}&fit=crop&auto=format`;

export const IMAGES = {
  heroFarmer: U("1500382017468-9049fed747ef", 1600, 1000),
  potato: U("1518977676601-b53f82aba655", 800, 600),
  alpaca: U("1524024973431-2ad916746881", 800, 600),
  quinoa: U("1586201375761-83865001e31c", 800, 600),
  onion: U("1580201092675-a0a6a6cafbb1", 800, 600),
  trout: U("1535591273668-578e31182c4f", 800, 600),
  truck: U("1601584115197-04ecc0da31d7", 800, 600),
  market: U("1488459716781-31db52582fe9", 800, 600),
  road: U("1469474968028-56623f02e42e", 800, 600),
  hands: U("1464226184884-fa280b87c399", 800, 600),
};

export const products: Product[] = [
  {
    id: "p1", name: "Papa Canchán", variety: "Canchán rosada", category: "papa",
    place: "Acora, Puno", quantity: "8 t disponibles", rangeLow: 1.9, rangeHigh: 2.4, unit: "kg",
    neg: "rapida", risk: "bajo", confidence: 86, updated: "hace 2 h",
    producer: "Asoc. Los Andes de Acora", verified: true, image: IMAGES.potato,
  },
  {
    id: "p2", name: "Fibra de alpaca", variety: "Baby, blanca clasificada", category: "alpaca",
    place: "Mazocruz, Puno", quantity: "1.2 t clasificada", rangeLow: 28, rangeHigh: 36, unit: "kg",
    neg: "conversacional", risk: "medio", confidence: 72, updated: "hace 5 h",
    producer: "Familia Mamani Quispe", verified: true, image: IMAGES.alpaca,
  },
  {
    id: "p3", name: "Quinua blanca", variety: "Salcedo INIA", category: "quinua",
    place: "Ilave, Puno", quantity: "5 t", rangeLow: 6.2, rangeHigh: 7.8, unit: "kg",
    neg: "conversacional", risk: "alto", confidence: 64, updated: "hace 1 día",
    producer: "Cooperativa Titicaca", verified: false, image: IMAGES.quinoa,
  },
  {
    id: "p4", name: "Papa Imilla", variety: "Imilla negra", category: "papa",
    place: "Juli, Puno", quantity: "3.5 t", rangeLow: 2.2, rangeHigh: 2.9, unit: "kg",
    neg: "rapida", risk: "bajo", confidence: 81, updated: "hace 3 h",
    producer: "Rosa Huanca", verified: true, image: IMAGES.hands,
  },
  {
    id: "p5", name: "Cebolla roja", variety: "Arequipeña", category: "cebolla",
    place: "Arequipa", quantity: "12 t", rangeLow: 1.4, rangeHigh: 1.9, unit: "kg",
    neg: "rapida", risk: "medio", confidence: 78, updated: "hace 6 h",
    producer: "Fundo El Pedregal", verified: true, image: IMAGES.onion,
  },
  {
    id: "p6", name: "Trucha fresca", variety: "Arcoíris entera", category: "trucha",
    place: "Juliaca, Puno", quantity: "600 kg / semana", rangeLow: 11, rangeHigh: 14, unit: "kg",
    neg: "conversacional", risk: "medio", confidence: 69, updated: "hace 4 h",
    producer: "Piscigranja Chucuito", verified: true, image: IMAGES.trout,
  },
];

export type Transporter = {
  id: string; name: string; type: string; vehicle: string; capacity: string;
  departure: string; duration: string; price: number; risk: RiskLevel;
  insurance: boolean; trips: number; rating: number; services: string[];
};

export const bids: Transporter[] = [
  { id: "t1", name: "Transportes Qhapaq", type: "Empresa", vehicle: "Camión 8 t furgón", capacity: "8 t",
    departure: "Mañana 05:00", duration: "6 h 30 min", price: 1850, risk: "bajo", insurance: true,
    trips: 214, rating: 4.8, services: ["Carga/descarga", "Ayudante", "Rastreo GPS"] },
  { id: "t2", name: "Wilfredo Ccama", type: "Independiente", vehicle: "Camioneta 4x4", capacity: "1.5 t",
    departure: "Hoy 14:00", duration: "5 h 10 min", price: 720, risk: "medio", insurance: false,
    trips: 46, rating: 4.5, services: ["4x4 trocha", "Retorno disponible"] },
  { id: "t3", name: "Flota Altiplano", type: "Empresa", vehicle: "Camión 12 t", capacity: "12 t",
    departure: "Mañana 04:00", duration: "6 h 50 min", price: 2400, risk: "bajo", insurance: true,
    trips: 388, rating: 4.9, services: ["Seguro carga", "Carga/descarga", "Refrigeración"] },
];

export type RiskEvent = {
  id: string; type: string; place: string; level: RiskLevel; confidence: number;
  window: string; source: string;
};

export const riskEvents: RiskEvent[] = [
  { id: "r1", type: "Protesta anunciada", place: "Corredor Ilave – Puno", level: "alto", confidence: 74, window: "Hoy 10:00 – 16:00", source: "Reporte comunitario + prensa" },
  { id: "r2", type: "Lluvia intensa", place: "Mazocruz altiplano", level: "medio", confidence: 81, window: "Próximas 12 h", source: "Senamhi (referencial)" },
  { id: "r3", type: "Trocha con barro", place: "Desvío Acora rural", level: "medio", confidence: 66, window: "48 h", source: "Transportistas" },
  { id: "r4", type: "Ruta despejada", place: "Juliaca – Arequipa", level: "bajo", confidence: 90, window: "Estable", source: "Sistema" },
];

export const vehicles = [
  "Pickup", "Camioneta 4x4", "Camión ligero", "Camión de 8 toneladas",
  "Camión de 12 toneladas", "Furgón cubierto",
];

export const riskMeta: Record<RiskLevel, { label: string; color: string; bg: string }> = {
  bajo: { label: "Riesgo bajo", color: "#0B6B4F", bg: "#DDF5E9" },
  medio: { label: "Riesgo medio", color: "#B5790F", bg: "#FBEFD6" },
  alto: { label: "Riesgo alto", color: "#B5591A", bg: "#FBE3D0" },
  critico: { label: "Riesgo crítico", color: "#C94A4A", bg: "#F7DADA" },
};
