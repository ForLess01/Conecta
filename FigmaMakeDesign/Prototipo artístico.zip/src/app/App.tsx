import { NavProvider, useNav } from "./lib/nav";
import { AppShell } from "./components/shell/AppShell";
import { Toaster } from "./components/ui/sonner";
import { Landing } from "./components/screens/Landing";
import { Login, RoleSelect } from "./components/screens/Auth";
import { Marketplace } from "./components/screens/Marketplace";
import { ProductDetail } from "./components/screens/ProductDetail";
import { Negotiation } from "./components/screens/Negotiation";
import { Order } from "./components/screens/Order";
import { Logistics } from "./components/screens/Logistics";
import { FreightCompare } from "./components/screens/FreightCompare";
import { Risk } from "./components/screens/Risk";
import { Trip } from "./components/screens/Trip";
import { ProducerDashboard, BuyerDashboard, TransporterDashboard } from "./components/screens/Dashboards";
import { Admin } from "./components/screens/Admin";
import { DesignSystem } from "./components/screens/DesignSystem";
import { Publish } from "./components/screens/Publish";

// Pantallas a pantalla completa (sin el shell de la app)
const FULLSCREEN = new Set(["landing", "login", "role", "design-system"]);

function Router() {
  const { screen } = useNav();

  const view = (() => {
    switch (screen) {
      case "landing": return <Landing />;
      case "login": return <Login />;
      case "role": return <RoleSelect />;
      case "design-system": return <DesignSystem />;
      case "marketplace": return <Marketplace />;
      case "product": return <ProductDetail />;
      case "negotiation": return <Negotiation />;
      case "order": return <Order />;
      case "logistics": return <Logistics />;
      case "freight-compare": return <FreightCompare />;
      case "risk": return <Risk />;
      case "trip": return <Trip />;
      case "publish": return <Publish />;
      case "admin": return <Admin />;
      case "dashboard-producer": return <ProducerDashboard />;
      case "dashboard-buyer": return <BuyerDashboard />;
      case "dashboard-transporter": return <TransporterDashboard />;
      default: return <Landing />;
    }
  })();

  if (FULLSCREEN.has(screen)) {
    return <div className="h-full w-full overflow-y-auto bg-background">{view}</div>;
  }
  return <AppShell>{view}</AppShell>;
}

export default function App() {
  return (
    <NavProvider>
      <div className="h-screen w-full">
        <Router />
        <Toaster position="top-center" />
      </div>
    </NavProvider>
  );
}
