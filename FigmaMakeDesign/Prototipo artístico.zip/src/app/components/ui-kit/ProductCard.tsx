import type { Product } from "../../lib/data";
import { ImageWithFallback } from "../figma/ImageWithFallback";
import { RiskBadge, ConfidenceBadge, NegBadge, VerifiedBadge, UpdatedBadge } from "./Badges";
import { CategoryIcon } from "../brand/CategoryIcon";
import { MapPin } from "lucide-react";

export function ProductCard({ product, onOpen }: { product: Product; onOpen: () => void }) {
  return (
    <button
      onClick={onOpen}
      className="group flex flex-col overflow-hidden rounded-2xl border border-border bg-card text-left transition-all hover:-translate-y-0.5 hover:shadow-[0_8px_28px_-12px_rgba(23,33,43,0.25)] focus:outline-none focus:ring-2 focus:ring-ring"
    >
      <div className="relative h-40 bg-secondary">
        <ImageWithFallback
          src={product.image}
          alt={`${product.name} — ${product.variety}, ${product.place}`}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
        />
        <div className="absolute left-3 top-3 flex gap-1.5">
          <span className="inline-flex items-center gap-1 rounded-full bg-card/90 px-2 py-1 text-[0.72rem] font-medium backdrop-blur">
            <CategoryIcon name={product.category} className="size-3.5 text-primary" />
            {product.name}
          </span>
        </div>
        <div className="absolute right-3 top-3">
          <RiskBadge level={product.risk} size="sm" />
        </div>
      </div>

      <div className="flex flex-1 flex-col gap-2 p-4">
        <div className="flex items-start justify-between gap-2">
          <div>
            <h3 className="text-[0.98rem] leading-tight">{product.variety}</h3>
            <p className="mt-0.5 inline-flex items-center gap-1 text-[0.78rem] text-muted-foreground">
              <MapPin size={12} /> {product.place} · {product.quantity}
            </p>
          </div>
        </div>

        <div className="mt-1 rounded-xl bg-accent/60 px-3 py-2">
          <p className="text-[0.68rem] uppercase tracking-wide text-muted-foreground">Rango orientativo</p>
          <p className="tnum text-[1.05rem] text-[#073F32]">
            S/ {product.rangeLow.toFixed(2)} – {product.rangeHigh.toFixed(2)}
            <span className="text-[0.72rem] text-muted-foreground"> / {product.unit}</span>
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          <NegBadge type={product.neg} />
          <ConfidenceBadge value={product.confidence} />
        </div>

        <div className="mt-auto flex items-center justify-between border-t border-border pt-2.5">
          <span className="flex items-center gap-1.5 text-[0.78rem] text-muted-foreground">
            {product.producer.length > 20 ? product.producer.slice(0, 20) + "…" : product.producer}
            {product.verified && <VerifiedBadge />}
          </span>
          <UpdatedBadge text={product.updated} />
        </div>
      </div>
    </button>
  );
}
