import { riskMeta, type RiskLevel, type NegType } from "../../lib/data";
import { CategoryIcon } from "../brand/CategoryIcon";
import { ShieldCheck, Zap, MessageSquare, Clock } from "lucide-react";

export function RiskBadge({ level, size = "md" }: { level: RiskLevel; size?: "sm" | "md" }) {
  const m = riskMeta[level];
  const dot = { bajo: "▪", medio: "▪▪", alto: "▪▪▪", critico: "▪▪▪▪" }[level];
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full font-medium transition-colors ${
        size === "sm" ? "px-2 py-0.5 text-[0.72rem]" : "px-2.5 py-1 text-[0.8rem]"
      }`}
      style={{ backgroundColor: m.bg, color: m.color }}
      role="status"
      aria-label={m.label}
    >
      <span aria-hidden style={{ letterSpacing: "-1px", fontSize: "0.6em" }}>{dot}</span>
      {m.label}
    </span>
  );
}

export function ConfidenceBadge({ value }: { value: number }) {
  const label = value >= 80 ? "Alta" : value >= 65 ? "Media" : "Baja";
  return (
    <span
      className="inline-flex items-center gap-1 rounded-full bg-[#EAF1F8] px-2 py-0.5 text-[0.72rem] font-medium text-[#3676B8]"
      title={`Confianza de la información: ${value}%`}
    >
      Confianza {label}
    </span>
  );
}

export function NegBadge({ type }: { type: NegType }) {
  return type === "rapida" ? (
    <span className="inline-flex items-center gap-1 rounded-full bg-[#DDF5E9] px-2 py-0.5 text-[0.72rem] font-medium text-[#073F32]">
      <Zap size={12} /> Negociación rápida
    </span>
  ) : (
    <span className="inline-flex items-center gap-1 rounded-full bg-[#EFE9DA] px-2 py-0.5 text-[0.72rem] font-medium text-[#6B5A2E]">
      <MessageSquare size={12} /> Conversacional
    </span>
  );
}

export function VerifiedBadge() {
  return (
    <span className="inline-flex items-center gap-1 text-[0.72rem] font-medium text-[#0B6B4F]">
      <ShieldCheck size={13} /> Verificado
    </span>
  );
}

export function UpdatedBadge({ text }: { text: string }) {
  return (
    <span className="inline-flex items-center gap-1 text-[0.72rem] text-muted-foreground">
      <Clock size={12} /> Actualizado {text}
    </span>
  );
}

export function CategoryChip({ name, label, active, onClick }: {
  name: Parameters<typeof CategoryIcon>[0]["name"]; label: string; active?: boolean; onClick?: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-[0.82rem] transition-colors ${
        active
          ? "border-transparent bg-primary text-primary-foreground"
          : "border-border bg-card text-foreground hover:border-primary/40 hover:bg-accent"
      }`}
    >
      <CategoryIcon name={name} className="size-4" />
      {label}
    </button>
  );
}
