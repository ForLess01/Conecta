import { useNav } from "../../lib/nav";
import { LogoMark, LogoFull } from "../brand/Logo";
import { CategoryIcon, type Category } from "../brand/CategoryIcon";
import { RiskBadge, ConfidenceBadge, NegBadge, VerifiedBadge } from "../ui-kit/Badges";
import { ArrowLeft, Loader2, Zap, WifiOff, Inbox } from "lucide-react";

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="border-t border-border py-8">
      <h2 className="text-[1.15rem]">{title}</h2>
      <div className="mt-4">{children}</div>
    </section>
  );
}

const swatches = [
  ["Verde profundo", "#0B6B4F"], ["Verde bosque", "#073F32"], ["Verde claro", "#DDF5E9"],
  ["Carbón", "#17212B"], ["Gris texto", "#52606D"], ["Fondo cálido", "#F7F6F1"],
  ["Arena", "#E7DFC8"], ["Ámbar", "#E99B22"], ["Rojo riesgo", "#C94A4A"], ["Azul info", "#3676B8"],
];

const allCats: { id: Category; l: string }[] = [
  { id: "papa", l: "Papa" }, { id: "alpaca", l: "Alpaca" }, { id: "quinua", l: "Quinua" },
  { id: "cebolla", l: "Cebolla" }, { id: "trucha", l: "Trucha" }, { id: "transporte", l: "Transporte" },
  { id: "ruta", l: "Ruta" }, { id: "riesgo", l: "Riesgo" }, { id: "oferta", l: "Oferta" }, { id: "negociacion", l: "Negociación" },
];

export function DesignSystem() {
  const { go } = useNav();
  return (
    <div className="mx-auto max-w-[1100px] px-4 py-6 md:px-7">
      <button onClick={() => go("landing")} className="inline-flex items-center gap-1.5 text-[0.85rem] text-muted-foreground hover:text-foreground"><ArrowLeft size={16} /> Inicio</button>
      <div className="mt-3">
        <h1 className="text-[1.7rem]">Sistema de diseño · Sendero</h1>
        <p className="mt-1 text-[0.9rem] text-muted-foreground">Identidad territorial andina — sobria, premium y accesible (WCAG AA).</p>
      </div>

      <Section title="Logo e isotipo">
        <div className="flex flex-wrap items-center gap-8">
          <div className="flex flex-col items-center gap-2"><LogoMark size={64} /><span className="text-[0.72rem] text-muted-foreground">Principal</span></div>
          <div className="flex flex-col items-center gap-2"><LogoMark size={64} variant="mono" /><span className="text-[0.72rem] text-muted-foreground">Monocromático</span></div>
          <div className="flex flex-col items-center gap-2 rounded-xl bg-[#073F32] p-3"><LogoMark size={64} variant="white" /><span className="text-[0.72rem] text-white/70">Blanco</span></div>
          <div className="flex flex-col items-center gap-2"><div className="grid size-16 place-items-center rounded-2xl bg-[#073F32]"><LogoMark size={40} variant="white" /></div><span className="text-[0.72rem] text-muted-foreground">App icon</span></div>
          <div className="flex flex-col items-center gap-2"><div className="grid size-8 place-items-center"><LogoMark size={24} /></div><span className="text-[0.72rem] text-muted-foreground">Favicon 24px</span></div>
          <LogoFull size={30} />
        </div>
      </Section>

      <Section title="Paleta">
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-5">
          {swatches.map(([n, c]) => (
            <div key={n} className="overflow-hidden rounded-xl border border-border">
              <div className="h-16" style={{ background: c }} />
              <div className="p-2"><p className="text-[0.78rem]">{n}</p><p className="tnum text-[0.72rem] text-muted-foreground">{c}</p></div>
            </div>
          ))}
        </div>
      </Section>

      <Section title="Tipografía">
        <div className="space-y-2">
          <p style={{ fontFamily: "var(--font-display)" }} className="text-[2rem]">Sora · Títulos</p>
          <p style={{ fontFamily: "var(--font-sans)" }} className="text-[1rem] text-muted-foreground">Inter · Texto de interfaz y párrafos largos legibles.</p>
          <p className="tnum text-[1.25rem]">1,234.56 · S/ 2.15/kg · tabular-nums para cifras</p>
        </div>
      </Section>

      <Section title="Iconografía de categorías">
        <div className="flex flex-wrap gap-4">
          {allCats.map((c) => (
            <div key={c.id} className="flex w-16 flex-col items-center gap-1.5">
              <span className="grid size-11 place-items-center rounded-xl bg-accent text-[#073F32]"><CategoryIcon name={c.id} className="size-6" /></span>
              <span className="text-[0.7rem] text-muted-foreground">{c.l}</span>
            </div>
          ))}
        </div>
      </Section>

      <Section title="Botones">
        <div className="flex flex-wrap items-center gap-3">
          <button className="rounded-xl bg-primary px-4 py-2.5 text-[0.85rem] text-primary-foreground hover:brightness-110">Primario</button>
          <button className="rounded-xl bg-secondary px-4 py-2.5 text-[0.85rem] text-secondary-foreground hover:brightness-95">Secundario</button>
          <button className="rounded-xl px-4 py-2.5 text-[0.85rem] hover:bg-accent">Ghost</button>
          <button className="rounded-xl bg-destructive px-4 py-2.5 text-[0.85rem] text-destructive-foreground hover:brightness-110">Destructivo</button>
          <button className="inline-flex items-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-[0.85rem] text-primary-foreground"><Zap size={15} /> Con icono</button>
          <button className="inline-flex items-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-[0.85rem] text-primary-foreground opacity-80"><Loader2 size={15} className="animate-spin" /> Cargando</button>
          <button disabled className="rounded-xl bg-primary px-4 py-2.5 text-[0.85rem] text-primary-foreground opacity-40">Disabled</button>
        </div>
      </Section>

      <Section title="Campos">
        <div className="grid max-w-xl gap-3 sm:grid-cols-2">
          <input placeholder="Texto" className="rounded-xl border border-border bg-input-background px-3 py-2.5 text-[0.9rem] outline-none focus:border-primary" />
          <div className="relative"><span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">S/</span><input defaultValue="2.15" className="tnum w-full rounded-xl border border-border bg-input-background py-2.5 pl-9 pr-3 text-[0.9rem] outline-none focus:border-primary" /></div>
          <div className="col-span-2 flex items-center gap-2">
            <button className="rounded-lg bg-muted px-3 py-2 text-[0.8rem]">−5 %</button>
            <input defaultValue="2.15" className="tnum flex-1 rounded-xl border border-border bg-input-background px-3 py-2.5 text-center text-[0.9rem] outline-none focus:border-primary" />
            <button className="rounded-lg bg-muted px-3 py-2 text-[0.8rem]">Referencia</button>
            <button className="rounded-lg bg-muted px-3 py-2 text-[0.8rem]">+5 %</button>
          </div>
        </div>
      </Section>

      <Section title="Badges">
        <div className="flex flex-wrap items-center gap-2">
          <RiskBadge level="bajo" /><RiskBadge level="medio" /><RiskBadge level="alto" /><RiskBadge level="critico" />
          <ConfidenceBadge value={85} /><ConfidenceBadge value={60} />
          <NegBadge type="rapida" /><NegBadge type="conversacional" /><VerifiedBadge />
          <span className="rounded-full bg-muted px-2.5 py-1 text-[0.72rem]">Múltiples productores</span>
          <span className="rounded-full bg-[#EAF1F8] px-2.5 py-1 text-[0.72rem] text-[#3676B8]">Transporte requerido</span>
          <span className="rounded-full bg-muted px-2.5 py-1 text-[0.72rem]">Patrocinado</span>
        </div>
      </Section>

      <Section title="Estados">
        <div className="grid gap-3 sm:grid-cols-3">
          {[
            { icon: Inbox, t: "Vacío", d: "Aún no hay resultados." },
            { icon: WifiOff, t: "Sin conexión", d: "Mostrando datos guardados." },
            { icon: Loader2, t: "Cargando", d: "Obteniendo información…", spin: true },
          ].map((s) => (
            <div key={s.t} className="flex flex-col items-center rounded-2xl border border-dashed border-border bg-card p-6 text-center">
              <s.icon size={22} className={`text-muted-foreground ${s.spin ? "animate-spin" : ""}`} />
              <p className="mt-2 text-[0.9rem]">{s.t}</p><p className="text-[0.78rem] text-muted-foreground">{s.d}</p>
            </div>
          ))}
        </div>
        <div className="mt-3 grid gap-3 sm:grid-cols-3">
          <div className="rounded-xl border border-border bg-card p-4"><div className="h-4 w-2/3 animate-pulse rounded bg-muted" /><div className="mt-2 h-3 w-full animate-pulse rounded bg-muted" /><div className="mt-1.5 h-3 w-4/5 animate-pulse rounded bg-muted" /></div>
          <div className="rounded-xl border border-[#C94A4A]/30 bg-[#F7DADA]/40 p-4 text-[0.85rem] text-[#8f2f2f]">Error: no se pudo cargar la ruta.</div>
          <div className="rounded-xl border border-[#E99B22]/40 bg-[#FBEFD6]/60 p-4 text-[0.85rem] text-[#8A5A00]">Información desactualizada hace 3 h.</div>
        </div>
      </Section>
    </div>
  );
}
