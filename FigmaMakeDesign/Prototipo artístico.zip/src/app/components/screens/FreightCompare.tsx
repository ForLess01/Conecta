import { useState } from "react";
import { useNav } from "../../lib/nav";
import { bids } from "../../lib/data";
import { RiskBadge } from "../ui-kit/Badges";
import { CategoryIcon } from "../brand/CategoryIcon";
import { ArrowLeft, ShieldCheck, Star, Clock, Truck, Check } from "lucide-react";

export function FreightCompare() {
  const { go } = useNav();
  const [selected, setSelected] = useState<string | null>(null);

  return (
    <div className="mx-auto max-w-[1100px] px-4 py-6 md:px-7">
      <button onClick={() => go("logistics")} className="inline-flex items-center gap-1.5 text-[0.85rem] text-muted-foreground hover:text-foreground">
        <ArrowLeft size={16} /> Volver
      </button>
      <div className="mt-3 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-[1.5rem]">Comparar ofertas de transporte</h1>
          <p className="mt-1 inline-flex items-center gap-1 text-[0.85rem] text-muted-foreground">
            <CategoryIcon name="ruta" className="size-4" /> Acora → Arequipa · 500 kg · {bids.length} ofertas recibidas
          </p>
        </div>
        <button onClick={() => go("risk")} className="rounded-xl border border-border bg-card px-3 py-2 text-[0.82rem] hover:bg-accent">Ver riesgo de la ruta</button>
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-3">
        {bids.map((b) => {
          const isSel = selected === b.id;
          return (
            <div key={b.id}
              className={`flex flex-col rounded-2xl border bg-card p-5 transition-all ${isSel ? "border-primary ring-2 ring-primary/30" : "border-border"}`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-[0.95rem]">{b.name}</p>
                  <p className="text-[0.75rem] text-muted-foreground">{b.type}</p>
                </div>
                <RiskBadge level={b.risk} size="sm" />
              </div>

              <div className="mt-4 rounded-xl bg-accent/60 p-3 text-center">
                <p className="text-[0.72rem] uppercase tracking-wide text-muted-foreground">Tarifa</p>
                <p className="tnum text-[1.4rem] text-[#073F32]">S/ {b.price.toLocaleString("es-PE")}</p>
              </div>

              <dl className="mt-4 space-y-2 text-[0.82rem]">
                {[
                  [<Truck size={14} />, "Vehículo", b.vehicle],
                  [<Clock size={14} />, "Salida", b.departure],
                  [<Clock size={14} />, "Duración", b.duration],
                  [<ShieldCheck size={14} />, "Seguro", b.insurance ? "Declarado" : "No declarado"],
                  [<Star size={14} />, "Experiencia", `${b.trips} viajes · ${b.rating}★`],
                ].map(([ic, k, v], i) => (
                  <div key={i} className="flex items-center justify-between gap-2">
                    <dt className="flex items-center gap-1.5 text-muted-foreground">{ic as any} {k as string}</dt>
                    <dd className="tnum text-right">{v as string}</dd>
                  </div>
                ))}
              </dl>

              <div className="mt-3 flex flex-wrap gap-1">
                {b.services.map((s) => <span key={s} className="rounded-full bg-muted px-2 py-0.5 text-[0.7rem]">{s}</span>)}
              </div>

              <button onClick={() => setSelected(b.id)}
                className={`mt-4 inline-flex items-center justify-center gap-2 rounded-xl py-2.5 text-[0.85rem] ${
                  isSel ? "bg-primary text-primary-foreground" : "border border-border hover:bg-accent"}`}>
                {isSel ? <><Check size={16} /> Seleccionado</> : "Seleccionar"}
              </button>
            </div>
          );
        })}
      </div>

      {selected && (
        <div className="mt-6 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-primary bg-accent/40 p-4">
          <p className="text-[0.88rem]">Confirmarás el transporte con <b>{bids.find((b) => b.id === selected)?.name}</b>. Esta acción reserva la carga.</p>
          <button onClick={() => go("trip")} className="rounded-xl bg-primary px-5 py-2.5 text-[0.88rem] text-primary-foreground hover:brightness-110">
            Confirmar y programar viaje
          </button>
        </div>
      )}
    </div>
  );
}
