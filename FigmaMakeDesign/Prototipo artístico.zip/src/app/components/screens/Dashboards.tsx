import { useNav } from "../../lib/nav";
import { products } from "../../lib/data";
import { RiskBadge, NegBadge } from "../ui-kit/Badges";
import { CategoryIcon } from "../brand/CategoryIcon";
import {
  BarChart, Bar, ResponsiveContainer, XAxis, Tooltip, LineChart, Line, CartesianGrid,
} from "recharts";
import { TrendingUp, Package, MessageSquare, Truck, Bell, Plus, ArrowRight, MapPin } from "lucide-react";

function KPI({ label, value, sub, tone = "green" }: { label: string; value: string; sub?: string; tone?: "green" | "amber" | "blue" }) {
  const c = tone === "amber" ? "#E99B22" : tone === "blue" ? "#3676B8" : "#0B6B4F";
  return (
    <div className="rounded-2xl border border-border bg-card p-4">
      <p className="text-[0.72rem] uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className="tnum mt-1 text-[1.5rem]" style={{ color: c }}>{value}</p>
      {sub && <p className="mt-0.5 text-[0.75rem] text-muted-foreground">{sub}</p>}
    </div>
  );
}

const priceData = [
  { m: "Feb", v: 1.8 }, { m: "Mar", v: 2.0 }, { m: "Abr", v: 1.95 },
  { m: "May", v: 2.1 }, { m: "Jun", v: 2.25 }, { m: "Jul", v: 2.15 },
];
const offerData = [
  { d: "L", v: 3 }, { d: "M", v: 5 }, { d: "X", v: 2 }, { d: "J", v: 6 }, { d: "V", v: 4 }, { d: "S", v: 8 },
];

function Header({ title, sub, cta, onCta }: { title: string; sub: string; cta?: string; onCta?: () => void }) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-3">
      <div><h1 className="text-[1.5rem]">{title}</h1><p className="mt-1 text-[0.85rem] text-muted-foreground">{sub}</p></div>
      {cta && <button onClick={onCta} className="inline-flex items-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-[0.85rem] text-primary-foreground hover:brightness-110"><Plus size={16} /> {cta}</button>}
    </div>
  );
}

export function ProducerDashboard() {
  const { go, openProduct } = useNav();
  return (
    <div className="mx-auto max-w-[1200px] px-4 py-6 md:px-7">
      <Header title="Hola, Rosa 👋" sub="Resumen de tu producción y negociaciones" cta="Publicar producto" onCta={() => go("publish")} />
      <div className="mt-5 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <KPI label="Ventas potenciales" value="S/ 18.4k" sub="+12% vs mes anterior" />
        <KPI label="Ofertas recibidas" value="7" sub="3 sin responder" tone="amber" />
        <KPI label="Productos activos" value="4" />
        <KPI label="Negociaciones" value="2" tone="blue" />
      </div>

      <div className="mt-5 grid gap-4 lg:grid-cols-[1.4fr_1fr]">
        <div className="rounded-2xl border border-border bg-card p-5">
          <div className="flex items-center justify-between"><h3 className="text-[0.95rem]">Precio de referencia · Papa Canchán</h3><span className="inline-flex items-center gap-1 text-[0.78rem] text-[#0B6B4F]"><TrendingUp size={14} /> S/ 2.15/kg</span></div>
          <div className="mt-3 h-48">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={priceData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#EEECE3" vertical={false} />
                <XAxis dataKey="m" tick={{ fontSize: 12, fill: "#52606D" }} axisLine={false} tickLine={false} />
                <Tooltip />
                <Line type="monotone" dataKey="v" stroke="#0B6B4F" strokeWidth={2.5} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="rounded-2xl border border-border bg-card p-5">
          <h3 className="text-[0.95rem]">Alertas de acceso</h3>
          <div className="mt-3 space-y-2">
            {[["Ruta Ilave–Puno", "alto"], ["Lluvia Mazocruz", "medio"], ["Juli despejado", "bajo"]].map(([l, r]) => (
              <div key={l} className="flex items-center justify-between rounded-xl bg-accent/50 px-3 py-2 text-[0.83rem]">
                <span className="flex items-center gap-1.5"><MapPin size={13} /> {l}</span>
                <RiskBadge level={r as any} size="sm" />
              </div>
            ))}
          </div>
        </div>
      </div>

      <h2 className="mt-8 text-[1.15rem]">Tus productos activos</h2>
      <div className="mt-3 grid gap-3 md:grid-cols-2">
        {products.filter((p) => p.category === "papa").concat(products.slice(1, 3)).map((p) => (
          <button key={p.id + Math.random()} onClick={() => openProduct(p.id)} className="flex items-center gap-3 rounded-xl border border-border bg-card p-3 text-left hover:border-primary/40">
            <img src={p.image} alt={p.name} className="size-12 rounded-lg object-cover" />
            <div className="min-w-0 flex-1"><p className="truncate text-[0.9rem]">{p.name} · {p.variety}</p><p className="tnum text-[0.78rem] text-muted-foreground">S/ {p.rangeLow.toFixed(2)}–{p.rangeHigh.toFixed(2)}/kg</p></div>
            <NegBadge type={p.neg} />
          </button>
        ))}
      </div>
    </div>
  );
}

export function BuyerDashboard() {
  const { go, openProduct } = useNav();
  return (
    <div className="mx-auto max-w-[1200px] px-4 py-6 md:px-7">
      <Header title="Panel del comprador" sub="Tus requerimientos y propuestas recibidas" cta="Publicar requerimiento" onCta={() => go("publish")} />
      <div className="mt-5 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <KPI label="Requerimientos activos" value="5" />
        <KPI label="Propuestas recibidas" value="14" sub="4 nuevas" tone="amber" />
        <KPI label="Órdenes" value="3" tone="blue" />
        <KPI label="Gasto estimado" value="S/ 62.3k" />
      </div>

      <div className="mt-5 grid gap-4 lg:grid-cols-[1fr_1.2fr]">
        <div className="rounded-2xl border border-border bg-card p-5">
          <h3 className="text-[0.95rem]">Alertas de ruta</h3>
          <div className="mt-3 space-y-2">
            {[["Acora → Arequipa", "medio"], ["Ilave → Puno", "alto"], ["Juliaca → Arequipa", "bajo"]].map(([l, r]) => (
              <button key={l} onClick={() => go("risk")} className="flex w-full items-center justify-between rounded-xl bg-accent/50 px-3 py-2 text-[0.83rem] hover:bg-accent">
                <span className="flex items-center gap-1.5"><MapPin size={13} /> {l}</span><RiskBadge level={r as any} size="sm" />
              </button>
            ))}
          </div>
        </div>
        <div className="rounded-2xl border border-border bg-card p-5">
          <h3 className="text-[0.95rem]">Recomendados para tu compra</h3>
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            {products.slice(0, 4).map((p) => (
              <button key={p.id} onClick={() => openProduct(p.id)} className="flex items-center gap-2 rounded-xl border border-border p-2 text-left hover:border-primary/40">
                <img src={p.image} alt={p.name} className="size-10 rounded-lg object-cover" />
                <div className="min-w-0"><p className="truncate text-[0.82rem]">{p.name}</p><p className="text-[0.72rem] text-muted-foreground">{p.place}</p></div>
              </button>
            ))}
          </div>
          <button onClick={() => go("marketplace")} className="mt-3 inline-flex items-center gap-1 text-[0.83rem] text-primary">Ir al marketplace <ArrowRight size={14} /></button>
        </div>
      </div>
    </div>
  );
}

export function TransporterDashboard() {
  const { go } = useNav();
  return (
    <div className="mx-auto max-w-[1200px] px-4 py-6 md:px-7">
      <Header title="Panel del transportista" sub="Cargas cercanas y tus viajes programados" cta="Ver cargas" onCta={() => go("freight-compare")} />
      <div className="mt-5 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <KPI label="Cargas cercanas" value="9" sub="3 con retorno" />
        <KPI label="Ofertas enviadas" value="4" tone="amber" />
        <KPI label="Viajes programados" value="2" tone="blue" />
        <KPI label="Ingresos estimados" value="S/ 8.2k" />
      </div>

      <div className="mt-5 grid gap-4 lg:grid-cols-[1.3fr_1fr]">
        <div className="rounded-2xl border border-border bg-card p-5">
          <h3 className="text-[0.95rem]">Ofertas enviadas esta semana</h3>
          <div className="mt-3 h-44">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={offerData}>
                <XAxis dataKey="d" tick={{ fontSize: 12, fill: "#52606D" }} axisLine={false} tickLine={false} />
                <Tooltip cursor={{ fill: "#F2F0E8" }} />
                <Bar dataKey="v" fill="#0B6B4F" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="rounded-2xl border border-border bg-card p-5">
          <h3 className="text-[0.95rem]">Cargas con retorno disponible</h3>
          <div className="mt-3 space-y-2">
            {[["Arequipa → Juliaca", "12 t", "bajo"], ["Puno → Acora", "1.5 t", "medio"], ["Ilave → Arequipa", "8 t", "alto"]].map(([r, c, risk]) => (
              <button key={r} onClick={() => go("freight-compare")} className="flex w-full items-center justify-between rounded-xl bg-accent/50 px-3 py-2 text-[0.83rem] hover:bg-accent">
                <span className="flex items-center gap-1.5"><CategoryIcon name="ruta" className="size-4" /> {r} · {c}</span>
                <RiskBadge level={risk as any} size="sm" />
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
