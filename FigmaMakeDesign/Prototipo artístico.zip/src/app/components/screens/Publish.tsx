import { useState } from "react";
import { useNav } from "../../lib/nav";
import { CategoryIcon, type Category } from "../brand/CategoryIcon";
import { Check, Info, Upload, ArrowRight, ArrowLeft, Lock } from "lucide-react";

const steps = ["Producto", "Calidad", "Cantidad", "Fotografías", "Ubicación", "Negociación", "Logística", "Vista previa"];

export function Publish() {
  const { go } = useNav();
  const [step, setStep] = useState(0);
  const [cat, setCat] = useState<Category>("papa");
  const [quick, setQuick] = useState(true);

  const cats: { id: Category; l: string }[] = [
    { id: "papa", l: "Papa" }, { id: "alpaca", l: "Fibra de alpaca" }, { id: "quinua", l: "Quinua" },
    { id: "cebolla", l: "Cebolla" }, { id: "trucha", l: "Trucha" },
  ];

  return (
    <div className="mx-auto max-w-3xl px-4 py-6 md:px-7">
      <button onClick={() => go("dashboard-producer")} className="inline-flex items-center gap-1.5 text-[0.85rem] text-muted-foreground hover:text-foreground"><ArrowLeft size={16} /> Salir</button>
      <h1 className="mt-3 text-[1.5rem]">Publicar producto</h1>

      {/* stepper */}
      <div className="mt-5 flex flex-wrap gap-1.5">
        {steps.map((s, i) => (
          <button key={s} onClick={() => setStep(i)}
            className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[0.75rem] ${
              i === step ? "bg-primary text-primary-foreground" : i < step ? "bg-accent text-[#073F32]" : "bg-muted text-muted-foreground"}`}>
            {i < step && <Check size={11} />} {i + 1}. {s}
          </button>
        ))}
      </div>

      <div className="mt-6 rounded-2xl border border-border bg-card p-6">
        {step === 0 && (
          <div>
            <h3 className="text-[1rem]">¿Qué producto vas a publicar?</h3>
            <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-3">
              {cats.map((c) => (
                <button key={c.id} onClick={() => setCat(c.id)}
                  className={`flex items-center gap-2 rounded-xl border p-3 text-left text-[0.85rem] ${cat === c.id ? "border-primary bg-accent/40" : "border-border hover:border-primary/40"}`}>
                  <CategoryIcon name={c.id} className="size-5 text-primary" /> {c.l}
                </button>
              ))}
            </div>
            <label className="mt-4 block text-[0.82rem] text-muted-foreground">Variedad</label>
            <input placeholder="Ej. Canchán rosada" className="mt-1 w-full rounded-xl border border-border bg-input-background px-3 py-2.5 text-[0.9rem] outline-none focus:border-primary" />
          </div>
        )}

        {step === 5 && (
          <div>
            <h3 className="text-[1rem]">Preferencias de negociación</h3>
            <label className="mt-4 flex items-center justify-between rounded-xl border border-border p-3">
              <span className="text-[0.88rem]">Habilitar negociación rápida (±5%)</span>
              <input type="checkbox" checked={quick} onChange={(e) => setQuick(e.target.checked)} className="size-5 accent-[#0B6B4F]" />
            </label>
            <label className="mt-3 block text-[0.82rem] text-muted-foreground">Precio mínimo privado</label>
            <div className="relative mt-1">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">S/</span>
              <input type="number" defaultValue={1.9} className="tnum w-full rounded-xl border border-border bg-input-background py-2.5 pl-9 pr-3 text-[0.9rem] outline-none focus:border-primary" />
            </div>
            <p className="mt-2 inline-flex items-center gap-1.5 rounded-lg bg-accent/60 px-2.5 py-1.5 text-[0.78rem] text-[#073F32]">
              <Lock size={13} /> Tu precio mínimo nunca será visible para el comprador.
            </p>
            <label className="mt-4 flex items-center justify-between rounded-xl border border-border p-3">
              <span className="text-[0.88rem]">Permitir negociación conversacional</span>
              <input type="checkbox" defaultChecked className="size-5 accent-[#0B6B4F]" />
            </label>
          </div>
        )}

        {step === 3 && (
          <div>
            <h3 className="text-[1rem]">Fotografías del producto</h3>
            <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
              {[0, 1, 2].map((i) => (
                <div key={i} className="grid aspect-square place-items-center rounded-xl border border-dashed border-border text-muted-foreground hover:border-primary/50">
                  <Upload size={20} />
                </div>
              ))}
            </div>
            <p className="mt-2 text-[0.78rem] text-muted-foreground">Usa luz natural y muestra la clasificación real del producto.</p>
          </div>
        )}

        {step === 7 && (
          <div className="text-center">
            <div className="mx-auto grid size-12 place-items-center rounded-full bg-accent text-[#0B6B4F]"><Check size={24} /></div>
            <h3 className="mt-3 text-[1.05rem]">Vista previa lista</h3>
            <p className="mt-1 text-[0.85rem] text-muted-foreground">Revisa tu publicación antes de hacerla visible en el marketplace.</p>
          </div>
        )}

        {![0, 3, 5, 7].includes(step) && (
          <div className="flex items-start gap-2 text-[0.88rem] text-muted-foreground">
            <Info size={16} className="mt-0.5 text-primary" />
            Paso “{steps[step]}”: completa los datos correspondientes. En este prototipo, el flujo es de demostración.
          </div>
        )}
      </div>

      <div className="mt-4 flex justify-between">
        <button disabled={step === 0} onClick={() => setStep((s) => s - 1)} className="rounded-xl border border-border px-4 py-2.5 text-[0.85rem] hover:bg-accent disabled:opacity-40">Atrás</button>
        {step < steps.length - 1 ? (
          <button onClick={() => setStep((s) => s + 1)} className="inline-flex items-center gap-1.5 rounded-xl bg-primary px-5 py-2.5 text-[0.85rem] text-primary-foreground hover:brightness-110">Siguiente <ArrowRight size={15} /></button>
        ) : (
          <button onClick={() => go("marketplace")} className="rounded-xl bg-primary px-5 py-2.5 text-[0.85rem] text-primary-foreground hover:brightness-110">Publicar</button>
        )}
      </div>
    </div>
  );
}
