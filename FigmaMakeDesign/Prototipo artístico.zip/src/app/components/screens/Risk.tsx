import { useNav } from "../../lib/nav";
import { riskEvents, riskMeta } from "../../lib/data";
import { RiskBadge, ConfidenceBadge } from "../ui-kit/Badges";
import { ArrowLeft, Info, CloudRain, Users, Route, TriangleAlert, ArrowRight } from "lucide-react";

export function Risk() {
  const { go } = useNav();
  const score = 62;
  const level = "alto" as const;
  const m = riskMeta[level];

  return (
    <div className="mx-auto max-w-[1000px] px-4 py-6 md:px-7">
      <button onClick={() => go("freight-compare")} className="inline-flex items-center gap-1.5 text-[0.85rem] text-muted-foreground hover:text-foreground">
        <ArrowLeft size={16} /> Volver
      </button>
      <h1 className="mt-3 text-[1.5rem]">Riesgo de la ruta Acora → Arequipa</h1>

      <div className="mt-5 grid gap-4 lg:grid-cols-[1fr_1fr]">
        {/* gauge */}
        <div className="rounded-2xl border border-border bg-card p-6">
          <div className="flex items-center gap-5">
            <Gauge value={score} color={m.color} />
            <div>
              <RiskBadge level={level} />
              <p className="mt-2 text-[0.82rem] text-muted-foreground">Índice compuesto 0–100</p>
              <div className="mt-2 flex items-center gap-2">
                <ConfidenceBadge value={68} />
                <span className="text-[0.75rem] text-muted-foreground">· Actualizado hace 40 min</span>
              </div>
            </div>
          </div>
          <p className="mt-4 flex items-start gap-2 rounded-xl bg-accent/60 p-3 text-[0.83rem] text-muted-foreground">
            <Info size={15} className="mt-0.5 shrink-0 text-primary" />
            El nivel se explica por una protesta anunciada en el corredor y lluvia intensa en el tramo alto. No implica que un actor sea “riesgoso”.
          </p>
        </div>

        {/* factores */}
        <div className="rounded-2xl border border-border bg-card p-6">
          <h3 className="text-[0.95rem]">Factores que explican el nivel</h3>
          <ul className="mt-3 space-y-3">
            {[
              { icon: Users, l: "Protesta anunciada (Ilave–Puno)", w: 40, c: "#C94A4A" },
              { icon: CloudRain, l: "Lluvia intensa tramo alto", w: 28, c: "#E99B22" },
              { icon: Route, l: "Trocha con barro en desvío", w: 18, c: "#E99B22" },
              { icon: TriangleAlert, l: "Antecedente de accidentes", w: 14, c: "#3676B8" },
            ].map((f) => (
              <li key={f.l}>
                <div className="flex items-center justify-between text-[0.83rem]">
                  <span className="flex items-center gap-2"><f.icon size={15} className="text-muted-foreground" /> {f.l}</span>
                  <span className="tnum text-muted-foreground">{f.w}%</span>
                </div>
                <div className="mt-1 h-1.5 w-full rounded-full bg-muted">
                  <div className="h-full rounded-full transition-all" style={{ width: `${f.w * 2.2}%`, background: f.c }} />
                </div>
              </li>
            ))}
          </ul>
          <p className="mt-3 text-[0.75rem] text-muted-foreground">Fuentes: reportes comunitarios, prensa local y Senamhi (referencial).</p>
        </div>
      </div>

      {/* ruta alternativa */}
      <div className="mt-4 grid gap-4 sm:grid-cols-3">
        {[
          { l: "Retraso estimado", v: "+1 h 20 min" },
          { l: "Costo adicional", v: "+ S/ 180" },
          { l: "Ruta alternativa", v: "Vía Juli (recomendada)" },
        ].map((d) => (
          <div key={d.l} className="rounded-2xl border border-border bg-card p-4">
            <p className="text-[0.72rem] uppercase tracking-wide text-muted-foreground">{d.l}</p>
            <p className="tnum mt-1 text-[1.05rem]">{d.v}</p>
          </div>
        ))}
      </div>

      <h2 className="mt-8 text-[1.15rem]">Eventos cercanos</h2>
      <div className="mt-3 grid gap-3 sm:grid-cols-2">
        {riskEvents.map((e) => (
          <div key={e.id} className="flex items-center justify-between rounded-xl border border-border bg-card p-4">
            <div>
              <p className="text-[0.88rem]">{e.type}</p>
              <p className="text-[0.75rem] text-muted-foreground">{e.place} · {e.window}</p>
            </div>
            <div className="flex flex-col items-end gap-1">
              <RiskBadge level={e.level} size="sm" />
              <ConfidenceBadge value={e.confidence} />
            </div>
          </div>
        ))}
      </div>

      <button onClick={() => go("trip")} className="mt-6 inline-flex items-center gap-1.5 rounded-xl bg-primary px-5 py-2.5 text-[0.88rem] text-primary-foreground hover:brightness-110">
        Continuar con ruta alternativa <ArrowRight size={16} />
      </button>
    </div>
  );
}

function Gauge({ value, color }: { value: number; color: string }) {
  const r = 42, c = 2 * Math.PI * r, off = c - (value / 100) * c;
  return (
    <div className="relative grid size-28 place-items-center">
      <svg viewBox="0 0 100 100" className="size-28 -rotate-90">
        <circle cx="50" cy="50" r={r} fill="none" stroke="#EEECE3" strokeWidth="9" />
        <circle cx="50" cy="50" r={r} fill="none" stroke={color} strokeWidth="9" strokeLinecap="round"
          strokeDasharray={c} strokeDashoffset={off} style={{ transition: "stroke-dashoffset 1s ease" }} />
      </svg>
      <span className="tnum absolute text-[1.5rem]" style={{ color }}>{value}</span>
    </div>
  );
}
