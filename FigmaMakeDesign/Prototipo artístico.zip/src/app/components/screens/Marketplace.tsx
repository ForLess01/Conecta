import { useState } from "react";
import { products } from "../../lib/data";
import { useNav } from "../../lib/nav";
import { ProductCard } from "../ui-kit/ProductCard";
import { CategoryChip } from "../ui-kit/Badges";
import { RiskBadge } from "../ui-kit/Badges";
import { SlidersHorizontal, ArrowUpDown, Grid2x2, Map as MapIcon, MapPin } from "lucide-react";
import { riskEvents } from "../../lib/data";

const cats = [
  { name: "papa" as const, label: "Papa" },
  { name: "alpaca" as const, label: "Fibra alpaca" },
  { name: "quinua" as const, label: "Quinua" },
  { name: "cebolla" as const, label: "Cebolla" },
  { name: "trucha" as const, label: "Trucha" },
];

export function Marketplace() {
  const { openProduct } = useNav();
  const [view, setView] = useState<"grid" | "map">("grid");
  const [active, setActive] = useState<string | null>(null);

  const list = active ? products.filter((p) => p.category === active) : products;

  return (
    <div className="mx-auto max-w-[1200px] px-4 py-6 md:px-7">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-[1.5rem]">Marketplace</h1>
          <p className="mt-1 inline-flex items-center gap-1 text-[0.85rem] text-muted-foreground">
            <MapPin size={14} /> Región Puno y Arequipa · {list.length} publicaciones activas
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button className="inline-flex items-center gap-1.5 rounded-xl border border-border bg-card px-3 py-2 text-[0.82rem] hover:bg-accent">
            <SlidersHorizontal size={15} /> Filtros
          </button>
          <button className="inline-flex items-center gap-1.5 rounded-xl border border-border bg-card px-3 py-2 text-[0.82rem] hover:bg-accent">
            <ArrowUpDown size={15} /> Ordenar
          </button>
          <div className="flex overflow-hidden rounded-xl border border-border">
            <button onClick={() => setView("grid")}
              className={`inline-flex items-center gap-1.5 px-3 py-2 text-[0.82rem] ${view === "grid" ? "bg-primary text-primary-foreground" : "bg-card hover:bg-accent"}`}>
              <Grid2x2 size={15} /> Cuadrícula
            </button>
            <button onClick={() => setView("map")}
              className={`inline-flex items-center gap-1.5 px-3 py-2 text-[0.82rem] ${view === "map" ? "bg-primary text-primary-foreground" : "bg-card hover:bg-accent"}`}>
              <MapIcon size={15} /> Mapa
            </button>
          </div>
        </div>
      </div>

      <div className="mt-5 flex flex-wrap gap-2">
        <CategoryChip name="ruta" label="Todos" active={!active} onClick={() => setActive(null)} />
        {cats.map((c) => (
          <CategoryChip key={c.name} name={c.name} label={c.label}
            active={active === c.name} onClick={() => setActive(c.name)} />
        ))}
      </div>

      {view === "grid" ? (
        <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((p) => (
            <ProductCard key={p.id} product={p} onOpen={() => openProduct(p.id)} />
          ))}
        </div>
      ) : (
        <div className="mt-6 grid gap-4 lg:grid-cols-[340px_1fr]">
          <div className="flex flex-col gap-3">
            {list.map((p) => (
              <button key={p.id} onClick={() => openProduct(p.id)}
                className="flex items-center gap-3 rounded-xl border border-border bg-card p-3 text-left hover:border-primary/40">
                <img src={p.image} alt={p.name} className="size-14 rounded-lg object-cover" />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[0.9rem]">{p.variety}</p>
                  <p className="text-[0.75rem] text-muted-foreground">{p.place}</p>
                  <p className="tnum text-[0.82rem] text-[#073F32]">S/ {p.rangeLow.toFixed(2)}–{p.rangeHigh.toFixed(2)}</p>
                </div>
                <RiskBadge level={p.risk} size="sm" />
              </button>
            ))}
          </div>
          <MapPanel />
        </div>
      )}
    </div>
  );
}

function MapPanel() {
  return (
    <div className="relative min-h-[420px] overflow-hidden rounded-2xl border border-border"
      style={{ background: "linear-gradient(135deg,#EAF0EA,#DDE7DE)" }}>
      {/* trazos de ruta estilizados */}
      <svg className="absolute inset-0 h-full w-full opacity-70" viewBox="0 0 400 300" preserveAspectRatio="none">
        <path d="M40 250 C 120 200, 140 120, 240 90 S 360 60, 380 40" fill="none" stroke="#0B6B4F" strokeWidth="2.5" strokeDasharray="6 6" />
        <path d="M60 60 C 140 90, 200 180, 320 230" fill="none" stroke="#3676B8" strokeWidth="2" strokeDasharray="2 6" />
      </svg>
      {[
        { x: "18%", y: "78%", r: "bajo" as const, l: "Acora" },
        { x: "58%", y: "30%", r: "medio" as const, l: "Mazocruz" },
        { x: "80%", y: "72%", r: "alto" as const, l: "Ilave" },
        { x: "42%", y: "55%", r: "bajo" as const, l: "Juli" },
      ].map((m) => (
        <div key={m.l} className="absolute -translate-x-1/2 -translate-y-1/2" style={{ left: m.x, top: m.y }}>
          <div className="flex flex-col items-center gap-1">
            <span className="rounded-full bg-card px-2 py-0.5 text-[0.68rem] shadow">{m.l}</span>
            <span className="size-3 rounded-full ring-4"
              style={{ background: m.r === "alto" ? "#C94A4A" : m.r === "medio" ? "#E99B22" : "#0B6B4F",
                       // @ts-ignore
                       "--tw-ring-color": "rgba(255,255,255,0.6)" }} />
          </div>
        </div>
      ))}
      <div className="absolute bottom-3 left-3 rounded-xl bg-card/95 p-3 text-[0.72rem] shadow backdrop-blur">
        <p className="mb-1.5 font-medium">Eventos de riesgo</p>
        {riskEvents.slice(0, 3).map((e) => (
          <div key={e.id} className="flex items-center gap-2 py-0.5">
            <span className="size-2 rounded-full"
              style={{ background: e.level === "alto" ? "#C94A4A" : e.level === "medio" ? "#E99B22" : "#0B6B4F" }} />
            {e.type} — {e.place}
          </div>
        ))}
      </div>
    </div>
  );
}
