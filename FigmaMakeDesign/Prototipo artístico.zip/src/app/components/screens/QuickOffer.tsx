import { useState } from "react";
import type { Product } from "../../lib/data";
import { useNav } from "../../lib/nav";
import { Dialog, DialogContent } from "../ui/dialog";
import { motion } from "motion/react";
import { X, Minus, Plus, Truck, CheckCircle2, RotateCcw, MessageSquare } from "lucide-react";

type Phase = "form" | "rejected" | "accepted";

export function QuickOffer({ product, onClose }: { product: Product; onClose: () => void }) {
  const { go } = useNav();
  const mid = +((product.rangeLow + product.rangeHigh) / 2).toFixed(2);
  const [price, setPrice] = useState(mid);
  const [qty] = useState(500);
  const [phase, setPhase] = useState<Phase>("form");
  const [attempts, setAttempts] = useState(3);

  const step = +(mid * 0.05).toFixed(2);
  const adjust = (dir: number) => setPrice((v) => +(v + dir * step).toFixed(2));

  const submit = () => {
    // Umbral simulado: acepta si la oferta alcanza ~el punto medio.
    if (price >= mid) setPhase("accepted");
    else { setAttempts((a) => Math.max(0, a - 1)); setPhase("rejected"); }
  };

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-md gap-0 overflow-hidden rounded-2xl p-0">
        <div className="flex items-center justify-between border-b border-border px-5 py-4">
          <h2 className="text-[1.05rem]">Oferta rápida</h2>
          <button onClick={onClose} className="rounded-lg p-1 hover:bg-accent"><X size={18} /></button>
        </div>

        {phase === "form" && (
          <div className="px-5 py-5">
            <div className="flex items-center gap-3">
              <img src={product.image} alt={product.name} className="size-12 rounded-lg object-cover" />
              <div>
                <p className="text-[0.9rem]">{product.name} — {product.variety}</p>
                <p className="tnum text-[0.78rem] text-muted-foreground">Cantidad: {qty} {product.unit}</p>
              </div>
            </div>

            <div className="mt-4 rounded-xl bg-accent/60 p-3 text-center">
              <p className="text-[0.72rem] uppercase tracking-wide text-muted-foreground">Rango sugerido</p>
              <p className="tnum text-[0.95rem] text-[#073F32]">S/ {product.rangeLow.toFixed(2)} – {product.rangeHigh.toFixed(2)}</p>
            </div>

            <label className="mt-4 block text-[0.8rem] text-muted-foreground">Tu precio por {product.unit}</label>
            <div className="mt-1.5 flex items-center gap-2">
              <button onClick={() => adjust(-1)} className="grid size-11 place-items-center rounded-xl border border-border hover:bg-accent" aria-label="Bajar 5%">
                <Minus size={16} /><span className="sr-only">-5%</span>
              </button>
              <div className="relative flex-1">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">S/</span>
                <input type="number" value={price} step={0.05}
                  onChange={(e) => setPrice(+e.target.value)}
                  className="tnum w-full rounded-xl border border-border py-2.5 pl-9 pr-3 text-center text-[1.1rem] outline-none focus:border-primary" />
              </div>
              <button onClick={() => adjust(1)} className="grid size-11 place-items-center rounded-xl border border-border hover:bg-accent" aria-label="Subir 5%">
                <Plus size={16} />
              </button>
            </div>
            <div className="mt-2 flex justify-center gap-2 text-[0.75rem]">
              <button onClick={() => adjust(-1)} className="rounded-full bg-muted px-2.5 py-1">−5 %</button>
              <button onClick={() => setPrice(mid)} className="rounded-full bg-muted px-2.5 py-1">Usar referencia</button>
              <button onClick={() => adjust(1)} className="rounded-full bg-muted px-2.5 py-1">+5 %</button>
            </div>

            <div className="mt-4 flex items-center justify-between border-t border-border pt-3">
              <span className="text-[0.82rem] text-muted-foreground">Subtotal ({qty} {product.unit})</span>
              <span className="tnum text-[1.05rem]">S/ {(price * qty).toLocaleString("es-PE", { minimumFractionDigits: 2 })}</span>
            </div>
            <p className="mt-2 inline-flex items-center gap-1.5 rounded-lg bg-[#FBEFD6] px-2.5 py-1.5 text-[0.75rem] text-[#8A5A00]">
              <Truck size={13} /> El transporte no está incluido en este subtotal.
            </p>
            <p className="mt-2 text-center text-[0.75rem] text-muted-foreground">Intentos disponibles: {attempts}</p>

            <button onClick={submit} disabled={attempts === 0}
              className="mt-3 w-full rounded-xl bg-primary py-3 text-[0.9rem] text-primary-foreground hover:brightness-110 disabled:opacity-50">
              Enviar oferta
            </button>
          </div>
        )}

        {phase === "rejected" && (
          <div className="px-5 py-8 text-center">
            <div className="mx-auto grid size-14 place-items-center rounded-full bg-[#FBE3D0] text-[#B5591A]"><RotateCcw size={24} /></div>
            <h3 className="mt-4 text-[1.1rem]">La propuesta no fue aceptada</h3>
            <p className="mt-1 text-[0.85rem] text-muted-foreground">
              Puedes mejorar tu oferta o pasar a una conversación. Te quedan {attempts} intentos.
            </p>
            <div className="mt-5 flex flex-col gap-2">
              <button onClick={() => setPhase("form")} className="w-full rounded-xl bg-primary py-2.5 text-[0.88rem] text-primary-foreground hover:brightness-110">
                Mejorar oferta
              </button>
              <button onClick={() => { onClose(); go("negotiation"); }}
                className="inline-flex w-full items-center justify-center gap-2 rounded-xl border border-border py-2.5 text-[0.88rem] hover:bg-accent">
                <MessageSquare size={16} /> Pasar a conversación
              </button>
              <button onClick={onClose} className="text-[0.82rem] text-muted-foreground hover:text-foreground">Cerrar</button>
            </div>
          </div>
        )}

        {phase === "accepted" && (
          <div className="px-5 py-8 text-center">
            <motion.div initial={{ scale: 0.6, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ type: "spring", stiffness: 260, damping: 18 }}
              className="mx-auto grid size-16 place-items-center rounded-full bg-[#DDF5E9] text-[#0B6B4F]">
              <CheckCircle2 size={30} />
            </motion.div>
            <h3 className="mt-4 text-[1.15rem]">¡Oferta aceptada!</h3>
            <div className="mt-4 space-y-1.5 rounded-xl bg-accent/60 p-4 text-left text-[0.85rem]">
              <div className="flex justify-between"><span className="text-muted-foreground">Precio acordado</span><span className="tnum">S/ {price.toFixed(2)} / {product.unit}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Cantidad reservada</span><span className="tnum">{qty} {product.unit}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Reserva vigente</span><span className="tnum text-[#B5591A]">23:59 min</span></div>
            </div>
            <button onClick={() => { onClose(); go("logistics"); }}
              className="mt-5 w-full rounded-xl bg-primary py-3 text-[0.9rem] text-primary-foreground hover:brightness-110">
              Siguiente: elegir logística
            </button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
