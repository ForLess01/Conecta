import { useState } from "react";
import { riskEvents } from "../../lib/data";
import { RiskBadge, ConfidenceBadge } from "../ui-kit/Badges";
import { BarChart, Bar, ResponsiveContainer, XAxis, Tooltip, PieChart, Pie, Cell } from "recharts";
import { Users, FileWarning, Handshake, Package, Truck, Plus, Check, X } from "lucide-react";

const tabs = ["Resumen", "Eventos de riesgo", "Precios", "Verificación"] as const;

const matchData = [
  { m: "Feb", v: 12 }, { m: "Mar", v: 18 }, { m: "Abr", v: 15 }, { m: "May", v: 24 }, { m: "Jun", v: 31 }, { m: "Jul", v: 28 },
];
const regionData = [
  { name: "Puno", v: 52, c: "#0B6B4F" }, { name: "Arequipa", v: 33, c: "#E99B22" }, { name: "Otros", v: 15, c: "#3676B8" },
];

export function Admin() {
  const [tab, setTab] = useState<(typeof tabs)[number]>("Resumen");
  return (
    <div className="mx-auto max-w-[1200px] px-4 py-6 md:px-7">
      <h1 className="text-[1.5rem]">Administración</h1>
      <p className="mt-1 text-[0.85rem] text-muted-foreground">Gestión de eventos, precios y usuarios · datos simulados</p>

      <div className="mt-5 flex gap-1 overflow-x-auto border-b border-border">
        {tabs.map((t) => (
          <button key={t} onClick={() => setTab(t)}
            className={`whitespace-nowrap border-b-2 px-3 py-2 text-[0.85rem] ${tab === t ? "border-primary text-foreground" : "border-transparent text-muted-foreground hover:text-foreground"}`}>{t}</button>
        ))}
      </div>

      {tab === "Resumen" && (
        <>
          <div className="mt-5 grid grid-cols-2 gap-3 lg:grid-cols-4">
            {[[Users, "Usuarios", "1,284"], [Handshake, "Negociaciones", "342"], [Package, "Órdenes", "128"], [Truck, "Envíos", "96"]].map(([I, l, v]: any) => (
              <div key={l} className="rounded-2xl border border-border bg-card p-4">
                <I size={18} className="text-primary" />
                <p className="tnum mt-2 text-[1.5rem]">{v}</p>
                <p className="text-[0.78rem] text-muted-foreground">{l}</p>
              </div>
            ))}
          </div>
          <div className="mt-5 grid gap-4 lg:grid-cols-[1.5fr_1fr]">
            <div className="rounded-2xl border border-border bg-card p-5">
              <h3 className="text-[0.95rem]">Matches por mes</h3>
              <div className="mt-3 h-52">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={matchData}>
                    <XAxis dataKey="m" tick={{ fontSize: 12, fill: "#52606D" }} axisLine={false} tickLine={false} />
                    <Tooltip cursor={{ fill: "#F2F0E8" }} />
                    <Bar dataKey="v" fill="#0B6B4F" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
            <div className="rounded-2xl border border-border bg-card p-5">
              <h3 className="text-[0.95rem]">Actividad por región</h3>
              <div className="mt-3 h-52">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={regionData} dataKey="v" nameKey="name" innerRadius={45} outerRadius={75} paddingAngle={3}>
                      {regionData.map((r) => <Cell key={r.name} fill={r.c} />)}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="flex justify-center gap-3 text-[0.75rem]">
                {regionData.map((r) => <span key={r.name} className="flex items-center gap-1"><span className="size-2 rounded-full" style={{ background: r.c }} /> {r.name}</span>)}
              </div>
            </div>
          </div>
        </>
      )}

      {tab === "Eventos de riesgo" && (
        <div className="mt-5">
          <div className="flex justify-between">
            <h3 className="text-[0.95rem]">Eventos registrados</h3>
            <button className="inline-flex items-center gap-1.5 rounded-xl bg-primary px-3 py-2 text-[0.82rem] text-primary-foreground"><Plus size={15} /> Crear evento</button>
          </div>
          <div className="mt-3 overflow-hidden rounded-2xl border border-border">
            <table className="w-full text-[0.83rem]">
              <thead className="bg-muted text-left text-muted-foreground">
                <tr>{["Tipo", "Lugar", "Nivel", "Confianza", "Vigencia", "Fuente"].map((h) => <th key={h} className="px-3 py-2 font-medium">{h}</th>)}</tr>
              </thead>
              <tbody>
                {riskEvents.map((e) => (
                  <tr key={e.id} className="border-t border-border bg-card">
                    <td className="px-3 py-2.5">{e.type}</td>
                    <td className="px-3 py-2.5 text-muted-foreground">{e.place}</td>
                    <td className="px-3 py-2.5"><RiskBadge level={e.level} size="sm" /></td>
                    <td className="px-3 py-2.5"><ConfidenceBadge value={e.confidence} /></td>
                    <td className="px-3 py-2.5 tnum text-muted-foreground">{e.window}</td>
                    <td className="px-3 py-2.5 text-muted-foreground">{e.source}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === "Precios" && (
        <div className="mt-5 rounded-2xl border border-border bg-card p-5">
          <h3 className="text-[0.95rem]">Observaciones de precios</h3>
          <p className="mt-1 text-[0.82rem] text-muted-foreground">Importa CSV o registra observaciones de mercado para alimentar los rangos sugeridos.</p>
          <div className="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {[["Papa Canchán", "Juliaca", "S/ 2.10"], ["Quinua blanca", "Ilave", "S/ 7.00"], ["Fibra alpaca", "Mazocruz", "S/ 33.00"], ["Cebolla", "Arequipa", "S/ 1.60"]].map(([p, m, v]) => (
              <div key={p} className="rounded-xl border border-border p-3"><p className="text-[0.85rem]">{p}</p><p className="text-[0.75rem] text-muted-foreground">{m}</p><p className="tnum mt-1 text-[0.95rem] text-[#073F32]">{v}/kg</p></div>
            ))}
          </div>
          <button className="mt-4 rounded-xl border border-border px-4 py-2 text-[0.82rem] hover:bg-accent">Importar CSV</button>
        </div>
      )}

      {tab === "Verificación" && (
        <div className="mt-5 space-y-2">
          {[["Cooperativa Titicaca", "Documentos declarados", "Pendiente"], ["Piscigranja Chucuito", "DNI + RUC", "Pendiente"], ["Flota Altiplano", "Tarjetas de propiedad", "Pendiente"]].map(([n, d, s]) => (
            <div key={n} className="flex items-center justify-between rounded-xl border border-border bg-card p-4">
              <div><p className="text-[0.9rem]">{n}</p><p className="text-[0.78rem] text-muted-foreground">{d}</p></div>
              <div className="flex items-center gap-2">
                <span className="rounded-full bg-[#FBEFD6] px-2.5 py-1 text-[0.72rem] text-[#8A5A00]">{s}</span>
                <button className="grid size-9 place-items-center rounded-xl bg-primary text-primary-foreground"><Check size={16} /></button>
                <button className="grid size-9 place-items-center rounded-xl border border-border hover:bg-accent"><X size={16} /></button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
