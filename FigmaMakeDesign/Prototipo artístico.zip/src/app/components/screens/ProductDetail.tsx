import { useState } from "react";
import { products } from "../../lib/data";
import { useNav } from "../../lib/nav";
import { ImageWithFallback } from "../figma/ImageWithFallback";
import { RiskBadge, ConfidenceBadge, NegBadge, VerifiedBadge, UpdatedBadge } from "../ui-kit/Badges";
import { CategoryIcon } from "../brand/CategoryIcon";
import { QuickOffer } from "./QuickOffer";
import { ArrowLeft, MapPin, Zap, MessageSquare, Truck, Info, ChevronRight } from "lucide-react";
import { ProductCard } from "../ui-kit/ProductCard";

export function ProductDetail() {
  const { productId, go, openProduct } = useNav();
  const p = products.find((x) => x.id === productId) ?? products[0];
  const [offerOpen, setOfferOpen] = useState(false);
  const similar = products.filter((x) => x.category === p.category && x.id !== p.id).concat(products).slice(0, 3);

  return (
    <div className="mx-auto max-w-[1100px] px-4 py-6 md:px-7">
      <button onClick={() => go("marketplace")} className="inline-flex items-center gap-1.5 text-[0.85rem] text-muted-foreground hover:text-foreground">
        <ArrowLeft size={16} /> Volver al marketplace
      </button>

      <div className="mt-4 grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
        {/* galería + datos */}
        <div>
          <div className="overflow-hidden rounded-2xl border border-border bg-secondary">
            <ImageWithFallback src={p.image} alt={`${p.name} ${p.variety}`} className="h-[320px] w-full object-cover" />
          </div>
          <div className="mt-3 grid grid-cols-4 gap-2">
            {[p.image, ...products.slice(0, 3).map((x) => x.image)].slice(0, 4).map((img, i) => (
              <div key={i} className="overflow-hidden rounded-xl border border-border bg-secondary">
                <img src={img} alt="" className="h-16 w-full object-cover" />
              </div>
            ))}
          </div>

          <div className="mt-6 grid gap-3 sm:grid-cols-3">
            {[
              { l: "Calidad", v: "Primera, seleccionada" },
              { l: "Cantidad", v: p.quantity },
              { l: "Unidad", v: `Precio por ${p.unit}` },
            ].map((d) => (
              <div key={d.l} className="rounded-xl border border-border bg-card p-3">
                <p className="text-[0.72rem] uppercase tracking-wide text-muted-foreground">{d.l}</p>
                <p className="mt-0.5 text-[0.9rem]">{d.v}</p>
              </div>
            ))}
          </div>

          {/* riesgo de acceso */}
          <button onClick={() => go("risk")} className="mt-4 flex w-full items-center justify-between rounded-2xl border border-border bg-card p-4 text-left hover:border-primary/40">
            <div>
              <p className="text-[0.72rem] uppercase tracking-wide text-muted-foreground">Riesgo de acceso a la zona</p>
              <div className="mt-1 flex items-center gap-2">
                <RiskBadge level={p.risk} />
                <ConfidenceBadge value={p.confidence} />
              </div>
            </div>
            <ChevronRight className="text-muted-foreground" />
          </button>

          {/* transporte estimado */}
          <div className="mt-4 flex items-center gap-3 rounded-2xl bg-accent/60 p-4">
            <Truck className="text-[#073F32]" />
            <div>
              <p className="text-[0.85rem]">Transporte estimado a Arequipa</p>
              <p className="tnum text-[0.8rem] text-muted-foreground">S/ 1,850 – 2,400 · 6–7 h · no incluido en el precio del producto</p>
            </div>
          </div>
        </div>

        {/* panel de compra */}
        <div className="lg:sticky lg:top-24 lg:self-start">
          <div className="rounded-2xl border border-border bg-card p-5">
            <div className="flex items-center gap-2">
              <span className="grid size-9 place-items-center rounded-xl bg-accent"><CategoryIcon name={p.category} className="size-5 text-primary" /></span>
              <div>
                <h1 className="text-[1.25rem] leading-tight">{p.name}</h1>
                <p className="text-[0.82rem] text-muted-foreground">{p.variety}</p>
              </div>
            </div>

            <p className="mt-3 inline-flex items-center gap-1 text-[0.82rem] text-muted-foreground">
              <MapPin size={13} /> {p.place} · ubicación aproximada
            </p>

            <div className="mt-4 rounded-xl bg-accent/60 p-4">
              <p className="text-[0.72rem] uppercase tracking-wide text-muted-foreground">Rango sugerido</p>
              <p className="tnum mt-0.5 text-[1.5rem] text-[#073F32]">
                S/ {p.rangeLow.toFixed(2)} – {p.rangeHigh.toFixed(2)}
                <span className="text-[0.8rem] text-muted-foreground"> / {p.unit}</span>
              </p>
              <p className="mt-1 inline-flex items-start gap-1 text-[0.74rem] text-muted-foreground">
                <Info size={13} className="mt-0.5 shrink-0" />
                Basado en observaciones de mercado en Puno y Arequipa. Orientativo, no obligatorio.
              </p>
            </div>

            <div className="mt-3 flex flex-wrap gap-1.5">
              <NegBadge type={p.neg} />
              <ConfidenceBadge value={p.confidence} />
            </div>

            <div className="mt-5 flex flex-col gap-2">
              <button onClick={() => setOfferOpen(true)}
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3 text-[0.9rem] text-primary-foreground hover:brightness-110">
                <Zap size={17} /> Oferta rápida
              </button>
              <button onClick={() => go("negotiation")}
                className="inline-flex items-center justify-center gap-2 rounded-xl border border-border px-4 py-3 text-[0.9rem] hover:bg-accent">
                <MessageSquare size={17} /> Conversar y negociar
              </button>
            </div>

            <div className="mt-5 flex items-center justify-between border-t border-border pt-4">
              <div className="flex items-center gap-2">
                <div className="grid size-9 place-items-center rounded-full bg-secondary text-[0.75rem]">
                  {p.producer.slice(0, 2).toUpperCase()}
                </div>
                <div>
                  <p className="text-[0.85rem]">{p.producer}</p>
                  {p.verified && <VerifiedBadge />}
                </div>
              </div>
              <UpdatedBadge text={p.updated} />
            </div>
          </div>
        </div>
      </div>

      <section className="mt-10">
        <h2 className="text-[1.25rem]">Productos similares</h2>
        <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {similar.map((s) => <ProductCard key={s.id + Math.random()} product={s} onOpen={() => openProduct(s.id)} />)}
        </div>
      </section>

      {offerOpen && <QuickOffer product={p} onClose={() => setOfferOpen(false)} />}
    </div>
  );
}
