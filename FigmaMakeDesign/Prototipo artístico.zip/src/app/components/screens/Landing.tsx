import { useNav } from "../../lib/nav";
import { LogoFull } from "../brand/Logo";
import { CategoryIcon } from "../brand/CategoryIcon";
import { ImageWithFallback } from "../figma/ImageWithFallback";
import { products, IMAGES, riskEvents } from "../../lib/data";
import { RiskBadge } from "../ui-kit/Badges";
import { ProductCard } from "../ui-kit/ProductCard";
import { Search, ArrowRight, Zap, MessageSquare, ShieldCheck, Truck, Users, Sprout, MapPin, Star } from "lucide-react";

export function Landing() {
  const { go, openProduct } = useNav();

  return (
    <div className="min-h-full bg-background">
      {/* nav */}
      <header className="mx-auto flex max-w-[1200px] items-center justify-between px-5 py-4">
        <LogoFull size={32} />
        <nav className="hidden items-center gap-6 text-[0.88rem] text-muted-foreground md:flex">
          <a className="hover:text-foreground" href="#actores">Cómo funciona</a>
          <a className="hover:text-foreground" href="#riesgo">Riesgo territorial</a>
          <a className="hover:text-foreground" href="#productos">Productos</a>
          <button className="hover:text-foreground" onClick={() => go("design-system")}>Design System</button>
        </nav>
        <div className="flex items-center gap-2">
          <button onClick={() => go("login")} className="rounded-xl px-4 py-2 text-[0.85rem] hover:bg-accent">Ingresar</button>
          <button onClick={() => go("role")} className="rounded-xl bg-primary px-4 py-2 text-[0.85rem] text-primary-foreground hover:brightness-110">
            Crear cuenta
          </button>
        </div>
      </header>

      {/* hero */}
      <section className="mx-auto grid max-w-[1200px] items-center gap-8 px-5 py-8 lg:grid-cols-[1.05fr_1fr] lg:py-12">
        <div>
          <span className="inline-flex items-center gap-2 rounded-full bg-accent px-3 py-1 text-[0.78rem] text-[#073F32]">
            <Sprout size={14} /> Plataforma rural del altiplano peruano
          </span>
          <h1 className="mt-4 text-[2.3rem] leading-[1.1] tracking-tight md:text-[3rem]">
            Encuentra el producto, negocia el precio y organiza el transporte.
          </h1>
          <p className="mt-4 max-w-xl text-[1.02rem] text-muted-foreground">
            Conectamos productores rurales, compradores y transportistas con información
            actualizada sobre costos orientativos y riesgo de las rutas andinas.
          </p>

          {/* buscador rápido */}
          <div className="mt-6 flex max-w-lg items-center gap-2 rounded-2xl border border-border bg-card p-2 shadow-sm">
            <Search size={18} className="ml-2 text-muted-foreground" />
            <input
              placeholder="Papa, quinua, fibra de alpaca, trucha…"
              className="min-w-0 flex-1 bg-transparent px-1 py-2 text-[0.9rem] outline-none"
              onKeyDown={(e) => e.key === "Enter" && go("marketplace")}
            />
            <button onClick={() => go("marketplace")} className="rounded-xl bg-primary px-4 py-2 text-[0.85rem] text-primary-foreground hover:brightness-110">
              Explorar
            </button>
          </div>
          <p className="mt-2 text-[0.78rem] text-muted-foreground">
            Los precios mostrados son orientativos, nunca obligatorios.
          </p>
        </div>

        <div className="relative">
          <div className="overflow-hidden rounded-[24px] border border-border bg-secondary shadow-[0_24px_60px_-30px_rgba(7,63,50,0.6)]">
            <ImageWithFallback src={IMAGES.heroFarmer}
              alt="Productora de papa en el altiplano peruano revisando su cosecha"
              className="h-[360px] w-full object-cover" />
          </div>
          <div className="absolute -bottom-5 -left-4 hidden rounded-2xl border border-border bg-card p-3 shadow-lg sm:block">
            <p className="text-[0.72rem] text-muted-foreground">Ruta Ilave → Puno</p>
            <div className="mt-1 flex items-center gap-2">
              <RiskBadge level="alto" size="sm" />
              <span className="text-[0.75rem] text-muted-foreground">Protesta anunciada</span>
            </div>
          </div>
          <div className="absolute -right-3 top-6 hidden rounded-2xl border border-border bg-card p-3 shadow-lg sm:block">
            <p className="text-[0.72rem] text-muted-foreground">Papa Canchán · Acora</p>
            <p className="tnum text-[0.95rem] text-[#073F32]">S/ 1.90 – 2.40 /kg</p>
          </div>
        </div>
      </section>

      {/* tres actores */}
      <section id="actores" className="mx-auto max-w-[1200px] px-5 py-10">
        <h2 className="text-[1.5rem]">Tres actores, una sola red</h2>
        <div className="mt-6 grid gap-4 md:grid-cols-3">
          {[
            { icon: Sprout, t: "Productor", d: "Publica tu producto, recibe un rango orientativo y elige cómo negociar.", c: "#DDF5E9" },
            { icon: Users, t: "Comprador", d: "Explora el marketplace, negocia rápido o conversa y arma tu orden.", c: "#EFE9DA" },
            { icon: Truck, t: "Transportista", d: "Encuentra cargas, oferta fletes y aprovecha el retorno disponible.", c: "#EAF1F8" },
          ].map((a) => (
            <div key={a.t} className="rounded-2xl border border-border bg-card p-5">
              <span className="grid size-11 place-items-center rounded-xl" style={{ background: a.c }}>
                <a.icon size={20} className="text-[#073F32]" />
              </span>
              <h3 className="mt-3 text-[1.1rem]">{a.t}</h3>
              <p className="mt-1 text-[0.88rem] text-muted-foreground">{a.d}</p>
            </div>
          ))}
        </div>
      </section>

      {/* dos negociaciones */}
      <section className="mx-auto max-w-[1200px] px-5 py-6">
        <div className="grid gap-4 md:grid-cols-2">
          <div className="rounded-2xl border border-border bg-card p-6">
            <span className="inline-flex items-center gap-2 text-[#0B6B4F]"><Zap size={18} /> Negociación rápida</span>
            <p className="mt-2 text-[0.92rem] text-muted-foreground">
              Envía una oferta con controles de ±5% sobre la referencia. El mínimo del productor
              nunca es visible. Respuesta inmediata.
            </p>
          </div>
          <div className="rounded-2xl border border-border bg-card p-6">
            <span className="inline-flex items-center gap-2 text-[#6B5A2E]"><MessageSquare size={18} /> Conversacional</span>
            <p className="mt-2 text-[0.92rem] text-muted-foreground">
              Chatea, comparte fotos y documentos, y crea propuestas estructuradas con
              vigencia clara hasta llegar a un match.
            </p>
          </div>
        </div>
      </section>

      {/* riesgo territorial */}
      <section id="riesgo" className="mx-auto max-w-[1200px] px-5 py-10">
        <div className="grid items-center gap-6 rounded-[24px] border border-border p-6 md:grid-cols-2"
          style={{ background: "linear-gradient(135deg,#073F32,#0B6B4F)" }}>
          <div className="text-white">
            <ShieldCheck size={22} />
            <h2 className="mt-3 text-[1.5rem] text-white">Riesgo territorial explicado, no un número suelto</h2>
            <p className="mt-2 text-[0.92rem] text-[#C9E6DA]">
              Cada ruta muestra nivel de riesgo, confianza de la información, última
              actualización y los factores que lo explican. Sin etiquetar a nadie como “riesgoso”.
            </p>
          </div>
          <div className="grid gap-2">
            {riskEvents.map((e) => (
              <div key={e.id} className="flex items-center justify-between rounded-xl bg-white/95 p-3">
                <div className="flex items-center gap-2 text-[0.85rem]">
                  <MapPin size={14} className="text-muted-foreground" /> {e.type}
                  <span className="text-muted-foreground">· {e.place}</span>
                </div>
                <RiskBadge level={e.level} size="sm" />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* pasos */}
      <section className="mx-auto max-w-[1200px] px-5 py-6">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {["Publica o explora", "Negocia el precio", "Elige el transporte", "Sigue el viaje"].map((s, i) => (
            <div key={s} className="rounded-2xl border border-border bg-card p-5">
              <span className="tnum text-[1.6rem] text-primary/30">0{i + 1}</span>
              <h3 className="mt-1 text-[1rem]">{s}</h3>
            </div>
          ))}
        </div>
      </section>

      {/* productos destacados */}
      <section id="productos" className="mx-auto max-w-[1200px] px-5 py-10">
        <div className="flex items-end justify-between">
          <h2 className="text-[1.5rem]">Productos destacados</h2>
          <button onClick={() => go("marketplace")} className="inline-flex items-center gap-1 text-[0.85rem] text-primary">
            Ver todo <ArrowRight size={15} />
          </button>
        </div>
        <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {products.slice(0, 3).map((p) => (
            <ProductCard key={p.id} product={p} onOpen={() => openProduct(p.id)} />
          ))}
        </div>
      </section>

      {/* testimonios (demostración) */}
      <section className="mx-auto max-w-[1200px] px-5 py-6">
        <div className="grid gap-4 md:grid-cols-3">
          {[
            { n: "Rosa Huanca", r: "Productora, Juli", t: "Publiqué mi papa Imilla y recibí ofertas el mismo día." },
            { n: "Comercial Andes SAC", r: "Comprador, Arequipa", t: "Comparar transporte y riesgo en un solo lugar nos ahorra tiempo." },
            { n: "Wilfredo Ccama", r: "Transportista", t: "El retorno disponible me ayuda a no volver con el camión vacío." },
          ].map((t) => (
            <figure key={t.n} className="rounded-2xl border border-border bg-card p-5">
              <div className="flex text-[#E99B22]">{Array.from({ length: 5 }).map((_, i) => <Star key={i} size={14} fill="#E99B22" />)}</div>
              <blockquote className="mt-2 text-[0.9rem]">“{t.t}”</blockquote>
              <figcaption className="mt-3 text-[0.8rem] text-muted-foreground">
                {t.n} · {t.r} <span className="ml-1 rounded bg-muted px-1.5 py-0.5 text-[0.68rem]">demostración</span>
              </figcaption>
            </figure>
          ))}
        </div>
      </section>

      {/* CTA final */}
      <section className="mx-auto max-w-[1200px] px-5 py-12">
        <div className="flex flex-col items-center gap-4 rounded-[24px] bg-[#17212B] px-6 py-12 text-center text-white">
          <h2 className="max-w-xl text-[1.8rem] text-white">Una plataforma hecha para el territorio, no para la ciudad.</h2>
          <div className="flex flex-wrap justify-center gap-3">
            <button onClick={() => go("role")} className="rounded-xl bg-primary px-5 py-2.5 text-[0.9rem] text-primary-foreground hover:brightness-110">
              Empezar ahora
            </button>
            <button onClick={() => go("marketplace")} className="rounded-xl border border-white/25 px-5 py-2.5 text-[0.9rem] hover:bg-white/10">
              Ver marketplace
            </button>
          </div>
        </div>
      </section>

      <footer className="border-t border-border">
        <div className="mx-auto flex max-w-[1200px] flex-col items-center justify-between gap-4 px-5 py-8 text-[0.8rem] text-muted-foreground md:flex-row">
          <LogoFull size={26} />
          <p>Sendero · Prototipo de demostración · Datos simulados</p>
          <div className="flex items-center gap-2">
            {(["papa", "alpaca", "quinua", "trucha", "transporte"] as const).map((c) => (
              <CategoryIcon key={c} name={c} className="size-5 text-muted-foreground" />
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
}
