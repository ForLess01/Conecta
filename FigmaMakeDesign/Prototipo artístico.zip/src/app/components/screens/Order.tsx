import { useState } from "react";
import { useNav } from "../../lib/nav";
import { products } from "../../lib/data";
import { RiskBadge } from "../ui-kit/Badges";
import { Check, Package, Truck, FileText, AlertCircle, Clock } from "lucide-react";

const tabs = ["Resumen", "Productores", "Logística", "Evidencias", "Historial"] as const;

export function Order() {
  const { go } = useNav();
  const [tab, setTab] = useState<(typeof tabs)[number]>("Resumen");
  const p = products[0];

  const timeline = [
    { l: "Match confirmado", done: true, t: "Hoy 09:22" },
    { l: "Orden creada", done: true, t: "Hoy 09:23" },
    { l: "Logística por definir", done: false, t: "Pendiente" },
    { l: "En transporte", done: false, t: "—" },
    { l: "Entregado", done: false, t: "—" },
  ];

  return (
    <div className="mx-auto max-w-[1000px] px-4 py-6 md:px-7">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-[1.5rem]">Orden #SND-2048</h1>
          <p className="text-[0.85rem] text-muted-foreground">Creada hoy · estado: logística pendiente</p>
        </div>
        <span className="inline-flex items-center gap-1.5 rounded-full bg-[#FBEFD6] px-3 py-1.5 text-[0.8rem] text-[#8A5A00]">
          <Clock size={14} /> Reserva vigente 23:41 min
        </span>
      </div>

      <div className="mt-5 flex gap-1 overflow-x-auto border-b border-border">
        {tabs.map((t) => (
          <button key={t} onClick={() => setTab(t)}
            className={`whitespace-nowrap border-b-2 px-3 py-2 text-[0.85rem] transition-colors ${
              tab === t ? "border-primary text-foreground" : "border-transparent text-muted-foreground hover:text-foreground"}`}>
            {t}
          </button>
        ))}
      </div>

      {tab === "Resumen" && (
        <div className="mt-5 grid gap-4 lg:grid-cols-[1fr_320px]">
          <div className="space-y-4">
            <div className="rounded-2xl border border-border bg-card p-4">
              <div className="flex items-center gap-3">
                <img src={p.image} alt={p.name} className="size-14 rounded-xl object-cover" />
                <div className="flex-1">
                  <p className="text-[0.95rem]">{p.name} — {p.variety}</p>
                  <p className="text-[0.8rem] text-muted-foreground">{p.producer} · {p.place}</p>
                </div>
                <RiskBadge level={p.risk} size="sm" />
              </div>
              <dl className="mt-4 grid grid-cols-2 gap-3 text-[0.85rem] sm:grid-cols-4">
                {[["Cantidad", "500 kg"], ["Precio", "S/ 2.15 /kg"], ["Subtotal", "S/ 1,075.00"], ["Logística", "Pendiente"]].map(([k, v]) => (
                  <div key={k}><dt className="text-muted-foreground text-[0.72rem] uppercase tracking-wide">{k}</dt><dd className="tnum mt-0.5">{v}</dd></div>
                ))}
              </dl>
            </div>
            <button onClick={() => go("logistics")}
              className="flex w-full items-center justify-between rounded-2xl border-2 border-dashed border-primary/40 bg-accent/40 p-4 text-left hover:bg-accent">
              <div className="flex items-center gap-3"><Truck className="text-primary" /><div><p className="text-[0.9rem]">Definir logística</p><p className="text-[0.78rem] text-muted-foreground">Elige quién transporta la carga</p></div></div>
              <span className="rounded-lg bg-primary px-3 py-1.5 text-[0.82rem] text-primary-foreground">Continuar</span>
            </button>
          </div>

          <aside className="rounded-2xl border border-border bg-card p-4">
            <h3 className="mb-3 text-[0.95rem]">Estado de la orden</h3>
            <ol className="relative ml-2 space-y-4 border-l border-border pl-5">
              {timeline.map((s) => (
                <li key={s.l} className="relative">
                  <span className={`absolute -left-[27px] grid size-5 place-items-center rounded-full ${s.done ? "bg-primary text-primary-foreground" : "border border-border bg-card"}`}>
                    {s.done && <Check size={12} />}
                  </span>
                  <p className={`text-[0.85rem] ${s.done ? "" : "text-muted-foreground"}`}>{s.l}</p>
                  <p className="text-[0.72rem] text-muted-foreground">{s.t}</p>
                </li>
              ))}
            </ol>
          </aside>
        </div>
      )}

      {tab === "Productores" && (
        <div className="mt-5 space-y-3">
          <p className="text-[0.85rem] text-muted-foreground">Orden con un solo productor. Los requerimientos grandes permiten combinar varios.</p>
          {[{ n: p.producer, q: "500 kg", pct: 100 }].map((r) => (
            <div key={r.n} className="flex items-center justify-between rounded-xl border border-border bg-card p-4">
              <span className="text-[0.9rem]">{r.n}</span>
              <span className="tnum text-[0.85rem]">{r.q} · {r.pct}% de la orden</span>
            </div>
          ))}
        </div>
      )}

      {tab === "Logística" && (
        <div className="mt-5 rounded-2xl border border-border bg-card p-6 text-center">
          <Truck className="mx-auto text-muted-foreground" />
          <p className="mt-2 text-[0.9rem]">Aún no defines la logística</p>
          <button onClick={() => go("logistics")} className="mt-3 rounded-xl bg-primary px-4 py-2 text-[0.85rem] text-primary-foreground">Elegir modalidad</button>
        </div>
      )}

      {tab === "Evidencias" && (
        <EmptyState icon={FileText} title="Sin evidencias todavía" desc="Las fotos de recojo y entrega aparecerán aquí." />
      )}
      {tab === "Historial" && (
        <div className="mt-5 space-y-2 text-[0.85rem]">
          {["Orden creada desde negociación conversacional", "Precio acordado S/ 2.15/kg", "Reserva de 24 h iniciada"].map((h, i) => (
            <div key={i} className="flex items-center gap-2 rounded-xl border border-border bg-card p-3"><AlertCircle size={15} className="text-muted-foreground" /> {h}</div>
          ))}
        </div>
      )}
    </div>
  );
}

export function EmptyState({ icon: Icon, title, desc }: { icon: typeof Package; title: string; desc: string }) {
  return (
    <div className="mt-5 flex flex-col items-center rounded-2xl border border-dashed border-border bg-card p-10 text-center">
      <div className="grid size-12 place-items-center rounded-full bg-muted text-muted-foreground"><Icon size={22} /></div>
      <p className="mt-3 text-[0.95rem]">{title}</p>
      <p className="mt-1 text-[0.82rem] text-muted-foreground">{desc}</p>
    </div>
  );
}
