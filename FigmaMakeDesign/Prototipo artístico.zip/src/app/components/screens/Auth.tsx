import { useNav, type Role } from "../../lib/nav";
import { LogoFull } from "../brand/Logo";
import { ImageWithFallback } from "../figma/ImageWithFallback";
import { IMAGES } from "../../lib/data";
import { Sprout, Users, Truck, Building2, ArrowLeft, Check } from "lucide-react";
import { useState } from "react";

export function Login() {
  const { go, setRole } = useNav();
  return (
    <div className="grid min-h-full lg:grid-cols-2">
      <div className="flex flex-col justify-center px-6 py-10 sm:px-16">
        <button onClick={() => go("landing")} className="mb-8 inline-flex items-center gap-1.5 text-[0.85rem] text-muted-foreground hover:text-foreground"><ArrowLeft size={16} /> Inicio</button>
        <LogoFull size={34} />
        <h1 className="mt-8 text-[1.7rem]">Bienvenido de nuevo</h1>
        <p className="mt-1 text-[0.9rem] text-muted-foreground">Ingresa con tu correo o teléfono</p>

        <div className="mt-6 max-w-sm space-y-3">
          <Field label="Correo o teléfono" placeholder="rosa@ejemplo.pe / 984 000 000" />
          <Field label="Contraseña" type="password" placeholder="••••••••" />
          <button className="text-[0.8rem] text-primary">¿Olvidaste tu contraseña?</button>
          <button onClick={() => go("dashboard-buyer")} className="w-full rounded-xl bg-primary py-3 text-[0.9rem] text-primary-foreground hover:brightness-110">Ingresar</button>
        </div>

        <p className="mt-6 text-[0.8rem] uppercase tracking-wide text-muted-foreground">Acceso de demostración</p>
        <div className="mt-2 flex max-w-sm flex-wrap gap-2">
          {([["productor", "dashboard-producer"], ["comprador", "dashboard-buyer"], ["transportista", "dashboard-transporter"]] as const).map(([r, s]) => (
            <button key={r} onClick={() => { setRole(r as Role); go(s as any); }}
              className="rounded-xl border border-border bg-card px-3 py-2 text-[0.82rem] capitalize hover:border-primary/40">{r}</button>
          ))}
        </div>
      </div>
      <div className="relative hidden bg-secondary lg:block">
        <ImageWithFallback src={IMAGES.market} alt="Mercado mayorista en Arequipa" className="h-full w-full object-cover" />
        <div className="absolute inset-0" style={{ background: "linear-gradient(0deg,rgba(7,63,50,0.55),transparent 60%)" }} />
      </div>
    </div>
  );
}

function Field({ label, type = "text", placeholder }: { label: string; type?: string; placeholder?: string }) {
  return (
    <label className="block">
      <span className="text-[0.82rem] text-muted-foreground">{label}</span>
      <input type={type} placeholder={placeholder}
        className="mt-1 w-full rounded-xl border border-border bg-input-background px-3 py-2.5 text-[0.9rem] outline-none focus:border-primary" />
    </label>
  );
}

export function RoleSelect() {
  const { go, setRole } = useNav();
  const [picked, setPicked] = useState<string[]>([]);
  const roles = [
    { id: "productor", icon: Sprout, t: "Soy productor", d: "Publico y vendo mi producción rural." },
    { id: "comprador", icon: Users, t: "Soy comprador", d: "Busco productos y negocio precios." },
    { id: "transportista", icon: Truck, t: "Soy transportista", d: "Ofrezco fletes y busco cargas." },
    { id: "organizacion", icon: Building2, t: "Represento una organización", d: "Cooperativa, asociación o empresa." },
  ];
  const toggle = (id: string) => setPicked((p) => p.includes(id) ? p.filter((x) => x !== id) : [...p, id]);

  return (
    <div className="mx-auto flex min-h-full max-w-2xl flex-col justify-center px-5 py-12">
      <button onClick={() => go("landing")} className="mb-6 inline-flex items-center gap-1.5 text-[0.85rem] text-muted-foreground hover:text-foreground"><ArrowLeft size={16} /> Inicio</button>
      <LogoFull size={32} />
      <h1 className="mt-6 text-[1.7rem]">¿Cómo usarás Sendero?</h1>
      <p className="mt-1 text-[0.9rem] text-muted-foreground">Puedes elegir más de un rol. Podrás cambiarlo cuando quieras.</p>
      <div className="mt-6 grid gap-3 sm:grid-cols-2">
        {roles.map((r) => {
          const on = picked.includes(r.id);
          return (
            <button key={r.id} onClick={() => toggle(r.id)}
              className={`relative rounded-2xl border p-5 text-left transition-all ${on ? "border-primary bg-accent/40 ring-2 ring-primary/20" : "border-border bg-card hover:border-primary/40"}`}>
              {on && <span className="absolute right-4 top-4 grid size-5 place-items-center rounded-full bg-primary text-primary-foreground"><Check size={13} /></span>}
              <span className="grid size-11 place-items-center rounded-xl bg-accent text-[#073F32]"><r.icon size={20} /></span>
              <h3 className="mt-3 text-[1.05rem]">{r.t}</h3>
              <p className="mt-1 text-[0.83rem] text-muted-foreground">{r.d}</p>
            </button>
          );
        })}
      </div>
      <button onClick={() => { if (picked[0]) setRole((picked[0] === "organizacion" ? "comprador" : picked[0]) as Role); go("dashboard-buyer"); }}
        disabled={!picked.length}
        className="mt-6 w-full rounded-xl bg-primary py-3 text-[0.9rem] text-primary-foreground hover:brightness-110 disabled:opacity-50">
        Continuar
      </button>
    </div>
  );
}
