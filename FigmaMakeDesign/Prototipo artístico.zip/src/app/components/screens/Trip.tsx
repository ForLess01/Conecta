import { useState } from "react";
import { useNav } from "../../lib/nav";
import { RiskBadge } from "../ui-kit/Badges";
import { ArrowLeft, Phone, Truck, MapPin, Camera, PackageCheck, CircleDot, Check } from "lucide-react";

export function Trip() {
  const { go } = useNav();
  const [stage] = useState(2);
  const steps = ["Programado", "Recojo registrado", "En viaje", "En destino", "Entregado"];

  return (
    <div className="mx-auto max-w-[1050px] px-4 py-6 md:px-7">
      <button onClick={() => go("freight-compare")} className="inline-flex items-center gap-1.5 text-[0.85rem] text-muted-foreground hover:text-foreground">
        <ArrowLeft size={16} /> Volver
      </button>
      <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-[1.5rem]">Seguimiento del viaje</h1>
          <p className="text-[0.85rem] text-muted-foreground">Viaje #VJ-771 · Acora → Arequipa (vía Juli)</p>
        </div>
        <RiskBadge level="medio" />
      </div>

      <div className="mt-5 grid gap-4 lg:grid-cols-[1.3fr_1fr]">
        {/* mapa ruta */}
        <div className="relative h-[300px] overflow-hidden rounded-2xl border border-border" style={{ background: "linear-gradient(135deg,#EAF0EA,#DDE7DE)" }}>
          <svg className="absolute inset-0 h-full w-full" viewBox="0 0 400 300" preserveAspectRatio="none">
            <path d="M50 240 C 130 200, 150 120, 250 100 S 350 60, 370 50" fill="none" stroke="#0B6B4F" strokeWidth="3" />
            <path d="M50 240 C 120 250, 220 250, 370 50" fill="none" stroke="#3676B8" strokeWidth="2" strokeDasharray="4 6" />
          </svg>
          {[{ x: "13%", y: "80%", l: "Acora (origen)" }, { x: "62%", y: "33%", l: "Juli (parada)" }, { x: "92%", y: "17%", l: "Arequipa" }].map((s) => (
            <div key={s.l} className="absolute -translate-x-1/2 -translate-y-1/2 flex flex-col items-center gap-1" style={{ left: s.x, top: s.y }}>
              <span className="rounded-full bg-card px-2 py-0.5 text-[0.68rem] shadow">{s.l}</span>
              <MapPin size={16} className="text-primary" fill="#DDF5E9" />
            </div>
          ))}
          <div className="absolute left-[45%] top-[50%] -translate-x-1/2 -translate-y-1/2">
            <span className="grid size-8 animate-pulse place-items-center rounded-full bg-primary text-primary-foreground shadow-lg"><Truck size={16} /></span>
          </div>
          <div className="absolute bottom-3 right-3 rounded-xl bg-card/95 p-2.5 text-[0.72rem] shadow">
            <p className="tnum">128 km recorridos · 84 km restantes</p>
            <p className="text-muted-foreground">ETA 15:40</p>
          </div>
        </div>

        {/* conductor + carga */}
        <div className="space-y-4">
          <div className="rounded-2xl border border-border bg-card p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="grid size-11 place-items-center rounded-full bg-secondary text-[0.8rem]">WC</div>
                <div><p className="text-[0.9rem]">Wilfredo Ccama</p><p className="text-[0.75rem] text-muted-foreground">Camioneta 4x4 · V2K-418</p></div>
              </div>
              <button className="grid size-10 place-items-center rounded-xl bg-primary text-primary-foreground"><Phone size={16} /></button>
            </div>
            <dl className="mt-4 grid grid-cols-2 gap-3 text-[0.82rem]">
              {[["Carga", "500 kg papa"], ["Paquetes", "10 sacos"], ["Estado", "En viaje"], ["Riesgo activo", "Lluvia (medio)"]].map(([k, v]) => (
                <div key={k}><dt className="text-[0.7rem] uppercase tracking-wide text-muted-foreground">{k}</dt><dd className="mt-0.5">{v}</dd></div>
              ))}
            </dl>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <button className="inline-flex items-center justify-center gap-2 rounded-xl border border-border bg-card py-3 text-[0.85rem] hover:bg-accent"><Camera size={16} /> Registrar recojo</button>
            <button className="inline-flex items-center justify-center gap-2 rounded-xl border border-border bg-card py-3 text-[0.85rem] hover:bg-accent"><PackageCheck size={16} /> Registrar entrega</button>
          </div>
        </div>
      </div>

      {/* timeline */}
      <div className="mt-6 rounded-2xl border border-border bg-card p-5">
        <div className="flex items-center justify-between">
          {steps.map((s, i) => (
            <div key={s} className="flex flex-1 flex-col items-center text-center">
              <div className="flex w-full items-center">
                <span className={`h-0.5 flex-1 ${i === 0 ? "bg-transparent" : i <= stage ? "bg-primary" : "bg-border"}`} />
                <span className={`grid size-7 shrink-0 place-items-center rounded-full ${
                  i < stage ? "bg-primary text-primary-foreground" : i === stage ? "bg-primary text-primary-foreground ring-4 ring-primary/20" : "border border-border bg-card text-muted-foreground"}`}>
                  {i < stage ? <Check size={13} /> : <CircleDot size={13} />}
                </span>
                <span className={`h-0.5 flex-1 ${i === steps.length - 1 ? "bg-transparent" : i < stage ? "bg-primary" : "bg-border"}`} />
              </div>
              <span className={`mt-2 text-[0.72rem] ${i <= stage ? "" : "text-muted-foreground"}`}>{s}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
