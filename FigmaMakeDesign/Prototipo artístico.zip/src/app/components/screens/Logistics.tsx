import { useNav } from "../../lib/nav";
import { CategoryIcon } from "../brand/CategoryIcon";
import { PackageCheck, Truck, HandCoins, ArrowLeft, ChevronRight } from "lucide-react";

export function Logistics() {
  const { go } = useNav();
  const options = [
    { icon: PackageCheck, t: "Recoge el comprador", d: "El comprador organiza y asume el traslado desde el origen.", cost: "Sin costo en plataforma", resp: "Responsabilidad del comprador", action: () => go("order") },
    { icon: HandCoins, t: "Entrega el productor", d: "El productor lleva la carga al destino acordado.", cost: "Incluido en el acuerdo", resp: "Responsabilidad del productor", action: () => go("order") },
    { icon: Truck, t: "Buscar transporte", d: "Publica la carga y recibe ofertas de transportistas.", cost: "Desde S/ 720 estimado", resp: "Comparas precio, tiempo y riesgo", action: () => go("freight-compare"), primary: true },
  ];

  return (
    <div className="mx-auto max-w-[1000px] px-4 py-6 md:px-7">
      <button onClick={() => go("order")} className="inline-flex items-center gap-1.5 text-[0.85rem] text-muted-foreground hover:text-foreground">
        <ArrowLeft size={16} /> Volver a la orden
      </button>
      <h1 className="mt-3 text-[1.5rem]">Elige la modalidad logística</h1>
      <p className="mt-1 text-[0.88rem] text-muted-foreground">Orden #SND-2048 · 500 kg de papa Canchán · Acora → Arequipa</p>

      <div className="mt-6 grid gap-4 md:grid-cols-3">
        {options.map((o) => (
          <button key={o.t} onClick={o.action}
            className={`flex flex-col rounded-2xl border p-5 text-left transition-all hover:-translate-y-0.5 hover:shadow-lg ${
              o.primary ? "border-primary bg-accent/40" : "border-border bg-card"}`}>
            <span className={`grid size-12 place-items-center rounded-xl ${o.primary ? "bg-primary text-primary-foreground" : "bg-accent text-[#073F32]"}`}>
              <o.icon size={22} />
            </span>
            <h3 className="mt-3 text-[1.05rem]">{o.t}</h3>
            <p className="mt-1 flex-1 text-[0.85rem] text-muted-foreground">{o.d}</p>
            <div className="mt-4 space-y-1 border-t border-border pt-3 text-[0.78rem]">
              <p className="text-[#073F32]">{o.cost}</p>
              <p className="text-muted-foreground">{o.resp}</p>
            </div>
            <span className="mt-3 inline-flex items-center gap-1 text-[0.82rem] text-primary">Elegir <ChevronRight size={15} /></span>
          </button>
        ))}
      </div>

      <div className="mt-6 flex items-center gap-3 rounded-2xl bg-accent/50 p-4 text-[0.82rem] text-muted-foreground">
        <CategoryIcon name="ruta" className="size-6 shrink-0 text-primary" />
        La ruta Acora → Arequipa presenta un tramo con riesgo medio por lluvia. Considéralo al elegir.
      </div>
    </div>
  );
}
