import { useState } from "react";
import { useNav } from "../../lib/nav";
import { products } from "../../lib/data";
import { NegBadge } from "../ui-kit/Badges";
import { Send, Paperclip, Image as ImageIcon, ArrowLeft, Check, CheckCheck, Clock } from "lucide-react";

type Msg = { id: number; from: "me" | "them" | "system"; text: string; time: string; read?: boolean };

export function Negotiation() {
  const { go } = useNav();
  const p = products[1];
  const [msgs, setMsgs] = useState<Msg[]>([
    { id: 1, from: "system", text: "Conversación iniciada sobre Fibra de alpaca — Mazocruz", time: "09:12" },
    { id: 2, from: "them", text: "Buen día. Tengo 1.2 t de fibra baby blanca clasificada, lista para entrega.", time: "09:13", read: true },
    { id: 3, from: "me", text: "Perfecto. ¿Cuál sería tu precio por kg para todo el lote?", time: "09:15", read: true },
    { id: 4, from: "them", text: "Estoy pensando en S/ 34 el kg. Puedo enviar fotos de la clasificación.", time: "09:16", read: true },
  ]);
  const [text, setText] = useState("");
  const [typing, setTyping] = useState(false);

  const send = () => {
    if (!text.trim()) return;
    setMsgs((m) => [...m, { id: Date.now(), from: "me", text, time: "09:20", read: false }]);
    setText("");
    setTyping(true);
    setTimeout(() => {
      setTyping(false);
      setMsgs((m) => [...m, { id: Date.now() + 1, from: "them", text: "De acuerdo, lo reviso y te confirmo la propuesta.", time: "09:21", read: true }]);
    }, 1600);
  };

  return (
    <div className="mx-auto max-w-[1100px] px-4 py-4 md:px-7 md:py-6">
      <button onClick={() => go("marketplace")} className="mb-3 inline-flex items-center gap-1.5 text-[0.85rem] text-muted-foreground hover:text-foreground md:hidden">
        <ArrowLeft size={16} /> Volver
      </button>
      <div className="grid gap-4 lg:grid-cols-[1fr_320px]">
        {/* chat */}
        <div className="flex h-[70vh] flex-col overflow-hidden rounded-2xl border border-border bg-card">
          <div className="flex items-center justify-between border-b border-border px-4 py-3">
            <div className="flex items-center gap-3">
              <img src={p.image} alt={p.producer} className="size-9 rounded-full object-cover" />
              <div>
                <p className="text-[0.9rem]">{p.producer}</p>
                <p className="text-[0.72rem] text-muted-foreground">{p.name} · {p.place}</p>
              </div>
            </div>
            <span className="inline-flex items-center gap-1 rounded-full bg-[#FBEFD6] px-2 py-1 text-[0.72rem] text-[#8A5A00]">
              <Clock size={12} /> Propuesta vence en 6 h
            </span>
          </div>

          <div className="flex-1 space-y-3 overflow-y-auto bg-[#FBFAF6] px-4 py-4">
            {msgs.map((m) =>
              m.from === "system" ? (
                <p key={m.id} className="mx-auto w-fit rounded-full bg-muted px-3 py-1 text-center text-[0.72rem] text-muted-foreground">{m.text}</p>
              ) : (
                <div key={m.id} className={`flex ${m.from === "me" ? "justify-end" : "justify-start"}`}>
                  <div className={`max-w-[75%] rounded-2xl px-3.5 py-2 text-[0.88rem] ${m.from === "me" ? "bg-primary text-primary-foreground" : "border border-border bg-card"}`}>
                    {m.text}
                    <span className={`mt-1 flex items-center justify-end gap-1 text-[0.65rem] ${m.from === "me" ? "text-white/70" : "text-muted-foreground"}`}>
                      {m.time} {m.from === "me" && (m.read ? <CheckCheck size={12} /> : <Check size={12} />)}
                    </span>
                  </div>
                </div>
              )
            )}
            {typing && <p className="w-fit rounded-full bg-muted px-3 py-1.5 text-[0.75rem] text-muted-foreground">{p.producer.split(" ")[0]} está escribiendo…</p>}
          </div>

          <div className="flex items-center gap-2 border-t border-border px-3 py-2.5">
            <button className="rounded-lg p-2 text-muted-foreground hover:bg-accent"><Paperclip size={18} /></button>
            <button className="rounded-lg p-2 text-muted-foreground hover:bg-accent"><ImageIcon size={18} /></button>
            <input value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send()}
              placeholder="Escribe un mensaje…" className="flex-1 rounded-xl border border-border bg-input-background px-3 py-2 text-[0.88rem] outline-none focus:border-primary" />
            <button onClick={send} className="grid size-10 place-items-center rounded-xl bg-primary text-primary-foreground hover:brightness-110"><Send size={17} /></button>
          </div>
        </div>

        {/* resumen comercial persistente */}
        <aside className="rounded-2xl border border-border bg-card p-4 lg:sticky lg:top-24 lg:self-start">
          <h3 className="text-[0.95rem]">Resumen comercial</h3>
          <NegBadge type="conversacional" />
          <dl className="mt-3 space-y-2 text-[0.85rem]">
            {[
              ["Producto", `${p.name} baby`],
              ["Cantidad", "1.2 t (lote)"],
              ["Última propuesta", "S/ 34.00 / kg"],
              ["Calidad", "Blanca clasificada"],
              ["Entrega", "En origen · Mazocruz"],
              ["Vigencia", "6 horas"],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between gap-2">
                <dt className="text-muted-foreground">{k}</dt><dd className="tnum text-right">{v}</dd>
              </div>
            ))}
          </dl>
          <div className="mt-3 rounded-xl bg-accent/60 p-3">
            <p className="text-[0.72rem] uppercase tracking-wide text-muted-foreground">Subtotal estimado</p>
            <p className="tnum text-[1.1rem] text-[#073F32]">S/ 40,800.00</p>
          </div>
          <button onClick={() => go("order")} className="mt-3 w-full rounded-xl bg-primary py-2.5 text-[0.88rem] text-primary-foreground hover:brightness-110">
            Crear propuesta y match
          </button>
          <button className="mt-2 w-full rounded-xl border border-border py-2.5 text-[0.85rem] hover:bg-accent">Crear propuesta estructurada</button>
        </aside>
      </div>
    </div>
  );
}
