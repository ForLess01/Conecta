/**
 * Isotipo original "Ruta" — sendero curvo que conecta dos nodos, con una hoja
 * abstracta creciendo del trazo, contenido en una silueta territorial hexagonal.
 * Funciona a 24px y a 512px. Sin texto dentro del isotipo.
 */

type MarkProps = {
  size?: number;
  variant?: "color" | "mono" | "white";
  className?: string;
};

export function LogoMark({ size = 32, variant = "color", className }: MarkProps) {
  const deep = variant === "white" ? "#FFFFFF" : variant === "mono" ? "#17212B" : "#0B6B4F";
  const dark = variant === "white" ? "#FFFFFF" : variant === "mono" ? "#17212B" : "#073F32";
  const leaf = variant === "white" ? "rgba(255,255,255,0.55)" : variant === "mono" ? "#52606D" : "#E99B22";

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 48 48"
      fill="none"
      className={className}
      role="img"
      aria-label="Logotipo Sendero"
    >
      {/* silueta territorial hexagonal */}
      <path
        d="M24 3.5 41.8 13.75V34.25L24 44.5 6.2 34.25V13.75Z"
        stroke={dark}
        strokeWidth="2.4"
        strokeLinejoin="round"
        fill="none"
        opacity={variant === "white" ? 0.5 : 0.9}
      />
      {/* sendero curvo */}
      <path
        d="M15 33 C 19 24, 21 21, 33 16"
        stroke={deep}
        strokeWidth="3.2"
        strokeLinecap="round"
        fill="none"
      />
      {/* hoja abstracta creciendo del trazo */}
      <path
        d="M27 20 C 29 15, 33 14, 33 14 C 33 14, 33 18, 30.5 20.5 C 29.2 21.8 27.8 21.4 27 20 Z"
        fill={leaf}
      />
      {/* nodos conectados */}
      <circle cx="15" cy="33" r="3.4" fill={dark} />
      <circle cx="33" cy="16" r="3.4" fill={deep} />
    </svg>
  );
}

export function LogoFull({ variant = "color", size = 32 }: MarkProps) {
  const text = variant === "white" ? "#FFFFFF" : "#17212B";
  return (
    <div className="flex items-center gap-2.5 select-none">
      <LogoMark size={size} variant={variant} />
      <span
        style={{ fontFamily: "var(--font-display)", color: text, fontWeight: 600 }}
        className="text-[1.15rem] tracking-tight"
      >
        Sendero
      </span>
    </div>
  );
}
