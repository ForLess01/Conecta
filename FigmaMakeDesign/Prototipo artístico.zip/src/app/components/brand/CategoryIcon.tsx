/**
 * Iconografía propia de categorías. Todos comparten grosor de trazo (1.8),
 * esquinas redondeadas y proporción sobre un lienzo de 24x24.
 */

export type Category =
  | "papa"
  | "alpaca"
  | "quinua"
  | "cebolla"
  | "trucha"
  | "transporte"
  | "ruta"
  | "riesgo"
  | "oferta"
  | "negociacion";

const base = {
  width: 22,
  height: 22,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.8,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
};

export function CategoryIcon({ name, className }: { name: Category; className?: string }) {
  const paths: Record<Category, JSX.Element> = {
    papa: (
      <>
        <path d="M8 7c-3 1-4 5-2.5 8.5S11 21 15 19s4.5-6 2.5-9.5S11 6 8 7Z" />
        <circle cx="9.5" cy="11" r="0.6" fill="currentColor" stroke="none" />
        <circle cx="13" cy="14" r="0.6" fill="currentColor" stroke="none" />
        <circle cx="11" cy="15.5" r="0.6" fill="currentColor" stroke="none" />
      </>
    ),
    alpaca: (
      <>
        <path d="M7 20v-4c0-3 1.5-5 4-5s4 2 4 5v4" />
        <path d="M9 11 8 6c0-1.2 1-2 2-1.5" />
        <path d="M15 11c1.5-.5 2.5-2 2.5-4" />
        <circle cx="17" cy="6" r="1.4" />
      </>
    ),
    quinua: (
      <>
        <path d="M12 21V8" />
        <path d="M12 8c-2-1-3.5.5-3 2.5M12 8c2-1 3.5.5 3 2.5" />
        <path d="M12 12c-2-1-3.5.5-3 2.5M12 12c2-1 3.5.5 3 2.5" />
        <path d="M12 5c-1.3-.6-2.3.3-2 1.8M12 5c1.3-.6 2.3.3 2 1.8" />
      </>
    ),
    cebolla: (
      <>
        <path d="M12 21c4 0 6-3 6-6.5C18 10 15 7 12 7s-6 3-6 7.5C6 18 8 21 12 21Z" />
        <path d="M12 7c-1-2 0-3.5 1-4M12 7c1-2 0-3.5-1-4" />
        <path d="M9.5 9c-.7 3-.7 6.5 0 10M14.5 9c.7 3 .7 6.5 0 10" />
      </>
    ),
    trucha: (
      <>
        <path d="M3 12c3-4 8-4 11-1 1.5-1.5 3-2 5-2-1 1.5-1 3.5 0 5-2 0-3.5-.5-5-2-3 3-8 3-11-1Z" />
        <circle cx="7" cy="11.2" r="0.6" fill="currentColor" stroke="none" />
      </>
    ),
    transporte: (
      <>
        <path d="M3 7h10v8H3z" />
        <path d="M13 10h4l3 3v2h-7z" />
        <circle cx="7" cy="17" r="1.6" />
        <circle cx="16.5" cy="17" r="1.6" />
      </>
    ),
    ruta: (
      <>
        <circle cx="6" cy="18" r="2" />
        <circle cx="18" cy="6" r="2" />
        <path d="M8 18c6 0 2-12 8-12" strokeDasharray="0.1 3" />
      </>
    ),
    riesgo: (
      <>
        <path d="M12 3 21 19H3Z" />
        <path d="M12 10v4" />
        <circle cx="12" cy="16.5" r="0.6" fill="currentColor" stroke="none" />
      </>
    ),
    oferta: (
      <>
        <path d="M4 12 12 4l8 8-8 8z" />
        <circle cx="9" cy="9" r="1.2" />
      </>
    ),
    negociacion: (
      <>
        <path d="M4 8h9l-2-2M20 16h-9l2 2" />
        <path d="M4 8v3M20 16v-3" />
      </>
    ),
  };

  return (
    <svg {...base} className={className} aria-hidden>
      {paths[name]}
    </svg>
  );
}
