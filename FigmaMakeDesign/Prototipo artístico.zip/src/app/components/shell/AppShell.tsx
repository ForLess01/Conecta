import type { ReactNode } from "react";
import { useNav, type Screen, type Role } from "../../lib/nav";
import { LogoFull, LogoMark } from "../brand/Logo";
import {
  Home, Store, ClipboardList, MessageSquare, Package, Truck,
  MapPin, Bell, User, Settings, HelpCircle, RefreshCw, Shield, Palette, Search, Plus,
} from "lucide-react";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuLabel, DropdownMenuSeparator,
} from "../ui/dropdown-menu";

const dashByRole: Record<Role, Screen> = {
  productor: "dashboard-producer",
  comprador: "dashboard-buyer",
  transportista: "dashboard-transporter",
};

const nav: { icon: typeof Home; label: string; screen: Screen }[] = [
  { icon: Home, label: "Inicio", screen: "dashboard-buyer" },
  { icon: Store, label: "Marketplace", screen: "marketplace" },
  { icon: ClipboardList, label: "Requerimientos", screen: "order" },
  { icon: MessageSquare, label: "Negociaciones", screen: "negotiation" },
  { icon: Package, label: "Órdenes", screen: "order" },
  { icon: Truck, label: "Transporte", screen: "freight-compare" },
  { icon: MapPin, label: "Viajes", screen: "trip" },
  { icon: Shield, label: "Riesgo", screen: "risk" },
];

const bottomNav: { icon: typeof Home; label: string; screen: Screen }[] = [
  { icon: Home, label: "Inicio", screen: "dashboard-buyer" },
  { icon: Search, label: "Explorar", screen: "marketplace" },
  { icon: Plus, label: "Publicar", screen: "publish" },
  { icon: MessageSquare, label: "Mensajes", screen: "negotiation" },
  { icon: User, label: "Perfil", screen: "dashboard-buyer" },
];

const roleLabels: Record<Role, string> = {
  productor: "Productor", comprador: "Comprador", transportista: "Transportista",
};

export function AppShell({ children }: { children: ReactNode }) {
  const { screen, go, role, setRole } = useNav();
  const isActive = (s: Screen) =>
    screen === s || (s === "dashboard-buyer" && screen === dashByRole[role]);

  return (
    <div className="flex h-full w-full bg-background text-foreground">
      {/* Sidebar desktop */}
      <aside
        className="hidden md:flex w-[240px] shrink-0 flex-col justify-between bg-sidebar text-sidebar-foreground"
        style={{ backgroundColor: "var(--green-forest)" }}
      >
        <div>
          <button onClick={() => go("landing")} className="flex w-full items-center px-5 py-5">
            <LogoFull variant="white" size={30} />
          </button>
          <nav className="mt-2 flex flex-col gap-0.5 px-3">
            {nav.map((n) => {
              const target = n.screen === "dashboard-buyer" ? dashByRole[role] : n.screen;
              const Icon = n.icon;
              const active = isActive(n.screen);
              return (
                <button
                  key={n.label}
                  onClick={() => go(target)}
                  className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-[0.9rem] transition-colors ${
                    active
                      ? "bg-[rgba(221,245,233,0.14)] text-white"
                      : "text-[#B8D9CC] hover:bg-[rgba(221,245,233,0.07)] hover:text-white"
                  }`}
                >
                  <Icon size={18} strokeWidth={active ? 2.4 : 1.8} />
                  {n.label}
                </button>
              );
            })}
          </nav>
        </div>

        <div className="px-3 pb-4">
          <div className="mb-2 rounded-xl bg-[rgba(221,245,233,0.08)] p-3">
            <p className="text-[0.7rem] uppercase tracking-wide text-[#8FBCAB]">Rol activo</p>
            <DropdownMenu>
              <DropdownMenuTrigger className="mt-1 flex w-full items-center justify-between text-[0.9rem] text-white">
                {roleLabels[role]}
                <RefreshCw size={14} className="text-[#8FBCAB]" />
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start">
                <DropdownMenuLabel>Cambiar rol</DropdownMenuLabel>
                <DropdownMenuSeparator />
                {(["productor", "comprador", "transportista"] as Role[]).map((r) => (
                  <DropdownMenuItem key={r} onClick={() => { setRole(r); go(dashByRole[r]); }}>
                    {roleLabels[r]}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          {[
            { icon: HelpCircle, label: "Ayuda", screen: "landing" as Screen },
            { icon: Palette, label: "Design System", screen: "design-system" as Screen },
            { icon: Shield, label: "Administración", screen: "admin" as Screen },
            { icon: Settings, label: "Configuración", screen: "landing" as Screen },
          ].map((n) => (
            <button key={n.label} onClick={() => go(n.screen)}
              className="flex w-full items-center gap-3 rounded-xl px-3 py-2 text-[0.85rem] text-[#B8D9CC] hover:bg-[rgba(221,245,233,0.07)] hover:text-white">
              <n.icon size={16} /> {n.label}
            </button>
          ))}
        </div>
      </aside>

      {/* Main column */}
      <div className="flex min-w-0 flex-1 flex-col">
        {/* Topbar */}
        <header className="sticky top-0 z-30 flex items-center gap-3 border-b border-border bg-card/85 px-4 py-3 backdrop-blur md:px-7">
          <button onClick={() => go("landing")} className="md:hidden">
            <LogoMark size={28} />
          </button>
          <div className="relative hidden flex-1 max-w-md sm:block">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              placeholder="Buscar productos, rutas o requerimientos"
              className="w-full rounded-xl border border-border bg-input-background py-2 pl-9 pr-3 text-[0.85rem] outline-none focus:border-primary"
              onFocus={() => go("marketplace")}
            />
          </div>
          <div className="ml-auto flex items-center gap-1">
            <button className="relative rounded-lg p-2 hover:bg-accent" aria-label="Notificaciones">
              <Bell size={18} />
              <span className="absolute right-1.5 top-1.5 size-2 rounded-full bg-[#E99B22]" />
            </button>
            <div className="flex items-center gap-2 rounded-full border border-border py-1 pl-1 pr-3">
              <div className="grid size-7 place-items-center rounded-full bg-primary text-[0.7rem] font-medium text-primary-foreground">MQ</div>
              <span className="hidden text-[0.82rem] sm:block">Mariela Q.</span>
            </div>
          </div>
        </header>

        <main className="min-h-0 flex-1 overflow-y-auto pb-20 md:pb-0">{children}</main>

        {/* Bottom nav mobile */}
        <nav className="fixed inset-x-0 bottom-0 z-40 grid grid-cols-5 border-t border-border bg-card md:hidden">
          {bottomNav.map((n) => {
            const Icon = n.icon;
            const active = screen === n.screen;
            const isPublish = n.label === "Publicar";
            return (
              <button key={n.label} onClick={() => go(n.screen)}
                className="flex flex-col items-center gap-0.5 py-2.5 text-[0.65rem]">
                <span className={isPublish ? "grid size-9 -mt-4 place-items-center rounded-full bg-primary text-primary-foreground shadow-lg" : ""}>
                  <Icon size={isPublish ? 20 : 20} className={active && !isPublish ? "text-primary" : isPublish ? "" : "text-muted-foreground"} />
                </span>
                <span className={active ? "text-primary" : "text-muted-foreground"}>{n.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
